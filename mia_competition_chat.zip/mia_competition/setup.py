from setuptools import setup
from glob import glob
import os

package_name = 'mia_competition'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name, 'testing'],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
        (os.path.join('share', package_name, 'models'), glob('models/*.md')),
        (os.path.join('share', package_name, 'testing'), glob('testing/*.py') + glob('testing/*.md')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='M.I.A Competition Team',
    maintainer_email='team@example.com',
    description='Real competition nodes for the M.I.A Piston Cup challenge.',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'competition_manager = mia_competition.competition_manager:main',
            'scroll_detector = mia_competition.scroll_detector:main',
            'operator_console = mia_competition.operator_console:main',
            'safety_controller = mia_competition.safety_controller:main',
            'test_camera = testing.test_camera:main',
            'test_ultrasonic = testing.test_ultrasonic:main',
            'test_cmd_vel_forward = testing.test_cmd_vel_forward:main',
        ],
    },
)
