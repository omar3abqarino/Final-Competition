#!/usr/bin/env python3
"""Competition state machine and autonomous search controller.

This node owns the competition mode and is the only node that normally sends
commands to /competition/cmd_vel. The safety controller later converts that to
/the real /cmd_vel after applying the ultrasonic limit.
"""

import json
import math
import time
from enum import Enum
from typing import Optional, Dict, Any

import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node
from std_msgs.msg import Float32, String


class State(Enum):
    IDLE = 'IDLE'
    AUTONOMOUS = 'AUTONOMOUS'
    WAITING_FOR_GREEN = 'WAITING_FOR_GREEN'
    MANUAL = 'MANUAL'
    STOPPED = 'STOPPED'
    FINISHED = 'FINISHED'


class CompetitionManager(Node):
    """Runs the real-match state machine and simple timed search."""

    def __init__(self) -> None:
        super().__init__('competition_manager')

        # Competition / robot parameters.
        self.declare_parameter('required_scrolls', 2)
        self.declare_parameter('scan_angle_deg', 120.0)
        self.declare_parameter('rotation_speed_rad_s', 0.7)
        self.declare_parameter('angle_tolerance_deg', 2.0)
        self.declare_parameter('forward_speed', 0.20)
        self.declare_parameter('forward_step_time_s', 1.0)
        self.declare_parameter('zone_a_steps', 3)
        self.declare_parameter('zone_b_steps', 3)
        self.declare_parameter('between_zone_time_s', 1.5)
        self.declare_parameter('detection_confirm_frames', 5)
        self.declare_parameter('detection_min_confidence', 0.55)
        self.declare_parameter('same_object_center_distance_ratio', 0.18)
        self.declare_parameter('detection_cooldown_s', 2.0)
        self.declare_parameter('rotate_settle_s', 0.10)

        self.required_scrolls = int(self.get_parameter('required_scrolls').value)
        self.scan_angle_rad = math.radians(float(self.get_parameter('scan_angle_deg').value))
        self.rotation_speed = float(self.get_parameter('rotation_speed_rad_s').value)
        self.forward_speed = float(self.get_parameter('forward_speed').value)
        self.forward_step_time = float(self.get_parameter('forward_step_time_s').value)
        self.zone_a_steps = int(self.get_parameter('zone_a_steps').value)
        self.zone_b_steps = int(self.get_parameter('zone_b_steps').value)
        self.between_zone_time = float(self.get_parameter('between_zone_time_s').value)
        self.confirm_frames_required = int(self.get_parameter('detection_confirm_frames').value)
        self.min_confidence = float(self.get_parameter('detection_min_confidence').value)
        self.center_distance_ratio = float(self.get_parameter('same_object_center_distance_ratio').value)
        self.cooldown_s = float(self.get_parameter('detection_cooldown_s').value)
        self.rotate_settle_s = float(self.get_parameter('rotate_settle_s').value)

        self.cmd_pub = self.create_publisher(Twist, '/competition/cmd_vel', 10)

        self.create_subscription(String, '/competition/operator_command', self.operator_callback, 10)
        self.create_subscription(String, '/competition/detections', self.detection_callback, 10)
        self.create_subscription(Twist, '/competition/manual_cmd_vel', self.manual_callback, 10)
        self.create_subscription(Float32, '/ultrasonic_distance', self.ultrasonic_callback, 10)

        self.timer = self.create_timer(0.02, self.control_loop)

        self.state = State.IDLE
        self.search_phase = 'ROTATE_OUT'
        self.zone = 'A'
        self.step_index = 0
        self.phase_start = time.monotonic()
        self.last_ultrasonic: Optional[float] = None
        self.manual_cmd = Twist()

        # Detection confirmation / duplicate filtering.
        self.confirmation_count = 0
        self.last_candidate: Optional[Dict[str, Any]] = None
        self.last_registered_time = -999.0
        self.registered_detections = []
        self.pending_stop_after_detection = False

        self.get_logger().info('Competition manager ready. Press ENTER in the operator window to start.')

    # ----------------------------- State control -----------------------------

    def set_state(self, new_state: State) -> None:
        if self.state == new_state:
            return
        self.state = new_state
        self.phase_start = time.monotonic()
        self.confirmation_count = 0
        self.last_candidate = None
        self.get_logger().info(f'State -> {new_state.value}')

    def operator_callback(self, msg: String) -> None:
        command = msg.data.strip().upper()

        if command == 'START_AUTO':
            self.reset_search()
            self.set_state(State.AUTONOMOUS)
        elif command == 'MANUAL':
            self.publish_stop()
            self.set_state(State.MANUAL)
        elif command == 'STOP':
            self.publish_stop()
            self.set_state(State.STOPPED)
        elif command == 'RESET':
            self.publish_stop()
            self.reset_search()
            self.set_state(State.IDLE)

    def reset_search(self) -> None:
        self.search_phase = 'ROTATE_OUT'
        self.zone = 'A'
        self.step_index = 0
        self.registered_detections.clear()
        self.pending_stop_after_detection = False
        self.manual_cmd = Twist()

    # ----------------------------- Inputs -----------------------------

    def ultrasonic_callback(self, msg: Float32) -> None:
        value = float(msg.data)
        if math.isfinite(value) and value >= 0.0:
            self.last_ultrasonic = value

    def manual_callback(self, msg: Twist) -> None:
        self.manual_cmd = msg

    def detection_callback(self, msg: String) -> None:
        if self.state != State.AUTONOMOUS:
            return

        try:
            packet = json.loads(msg.data)
            detections = packet.get('detections', [])
            image_width = max(1, int(packet.get('image_width', 1)))
        except (json.JSONDecodeError, TypeError, ValueError):
            return

        candidates = [
            d for d in detections
            if float(d.get('confidence', 0.0)) >= self.min_confidence
        ]
        if not candidates:
            self.confirmation_count = 0
            self.last_candidate = None
            return

        # Use the highest-confidence candidate for temporal confirmation.
        candidate = max(candidates, key=lambda x: float(x.get('confidence', 0.0)))
        candidate = dict(candidate)
        candidate['_center_ratio'] = float(candidate.get('center_x', 0.0)) / image_width

        if self.last_candidate is not None:
            delta = abs(candidate['_center_ratio'] - self.last_candidate['_center_ratio'])
            if delta <= self.center_distance_ratio:
                self.confirmation_count += 1
            else:
                self.confirmation_count = 1
        else:
            self.confirmation_count = 1

        self.last_candidate = candidate

        if self.confirmation_count >= self.confirm_frames_required:
            self.register_candidate(candidate)

    def register_candidate(self, candidate: Dict[str, Any]) -> None:
        now = time.monotonic()
        if now - self.last_registered_time < self.cooldown_s:
            return

        # A detection registered at the same scan step and with a similar image
        # location is treated as the same physical observation.
        for old in self.registered_detections:
            if old['zone'] == self.zone and old['step'] == self.step_index:
                center_delta = abs(old['center_ratio'] - candidate['_center_ratio'])
                if center_delta <= self.center_distance_ratio:
                    return

        item = {
            'class_name': str(candidate.get('class_name', 'unknown')),
            'confidence': float(candidate.get('confidence', 0.0)),
            'center_ratio': float(candidate['_center_ratio']),
            'zone': self.zone,
            'step': self.step_index,
        }
        self.registered_detections.append(item)
        self.last_registered_time = now
        self.confirmation_count = 0
        self.last_candidate = None

        self.publish_stop()
        self.get_logger().info(
            f'Scroll confirmed: class={item["class_name"]}, '
            f'confidence={item["confidence"]:.2f}, '
            f'count={len(self.registered_detections)}/{self.required_scrolls}'
        )

        if len(self.registered_detections) >= self.required_scrolls:
            self.set_state(State.WAITING_FOR_GREEN)
        else:
            # Let the robot leave this view before the next scan.
            self.search_phase = 'FORWARD_AFTER_DETECTION'
            self.phase_start = now

    # ----------------------------- Motion -----------------------------

    def publish(self, linear: float = 0.0, angular: float = 0.0) -> None:
        msg = Twist()
        msg.linear.x = float(linear)
        msg.angular.z = float(angular)
        self.cmd_pub.publish(msg)

    def publish_stop(self) -> None:
        self.publish(0.0, 0.0)

    def elapsed(self) -> float:
        return time.monotonic() - self.phase_start

    def rotate_duration(self) -> float:
        return self.scan_angle_rad / max(self.rotation_speed, 1e-3)

    # ----------------------------- Autonomous search -----------------------------

    def autonomous_loop(self) -> None:
        if len(self.registered_detections) >= self.required_scrolls:
            self.publish_stop()
            self.set_state(State.WAITING_FOR_GREEN)
            return

        rotation_time = self.rotate_duration()

        if self.search_phase == 'ROTATE_OUT':
            self.publish(0.0, self.rotation_speed)
            if self.elapsed() >= rotation_time:
                self.search_phase = 'ROTATE_BACK'
                self.phase_start = time.monotonic()

        elif self.search_phase == 'ROTATE_BACK':
            self.publish(0.0, -self.rotation_speed)
            if self.elapsed() >= rotation_time:
                self.publish_stop()
                self.search_phase = 'SETTLE'
                self.phase_start = time.monotonic()

        elif self.search_phase == 'SETTLE':
            self.publish_stop()
            if self.elapsed() >= self.rotate_settle_s:
                self.search_phase = 'FORWARD'
                self.phase_start = time.monotonic()

        elif self.search_phase in ('FORWARD', 'FORWARD_AFTER_DETECTION'):
            # If an object has just been detected, move only a short calibrated
            # amount so we do not deliberately drive into it.
            self.publish(self.forward_speed, 0.0)
            forward_time = self.forward_step_time
            if self.search_phase == 'FORWARD_AFTER_DETECTION':
                forward_time = min(self.forward_step_time, 0.6)

            if self.elapsed() >= forward_time:
                self.publish_stop()
                self.step_index += 1
                self.advance_zone_or_continue()

        elif self.search_phase == 'ZONE_CHANGE':
            self.publish(self.forward_speed, 0.0)
            if self.elapsed() >= self.between_zone_time:
                self.publish_stop()
                self.search_phase = 'ROTATE_OUT'
                self.phase_start = time.monotonic()
                self.step_index = 0

    def advance_zone_or_continue(self) -> None:
        limit = self.zone_a_steps if self.zone == 'A' else self.zone_b_steps
        if self.step_index < limit:
            self.search_phase = 'ROTATE_OUT'
            self.phase_start = time.monotonic()
            return

        if self.zone == 'A':
            self.zone = 'B'
            self.search_phase = 'ZONE_CHANGE'
            self.phase_start = time.monotonic()
        else:
            # We have completed the planned coverage. Continue with another
            # pass only if both scrolls were not found. This is deliberately
            # conservative and easy to tune.
            self.zone = 'A'
            self.step_index = 0
            self.search_phase = 'ROTATE_OUT'
            self.phase_start = time.monotonic()

    # ----------------------------- Main loop -----------------------------

    def control_loop(self) -> None:
        if self.state == State.AUTONOMOUS:
            self.autonomous_loop()
        elif self.state == State.MANUAL:
            self.publish(self.manual_cmd.linear.x, self.manual_cmd.angular.z)
        elif self.state in (State.IDLE, State.WAITING_FOR_GREEN, State.STOPPED, State.FINISHED):
            self.publish_stop()


def main(args=None) -> None:
    rclpy.init(args=args)
    node = CompetitionManager()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.publish_stop()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
