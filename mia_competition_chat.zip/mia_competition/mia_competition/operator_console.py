#!/usr/bin/env python3
"""Simple live camera window and competition keyboard controller.

Keys:
  ENTER : start autonomous competition search
  M     : switch from autonomous/waiting to MANUAL (green-card action)
  W/A/S/D : manual driving
  SPACE : emergency stop
  R     : reset to idle
  Q/ESC : close this operator window

Manual commands time out quickly so the robot stops if keyboard input is lost.
"""

import cv2
import rclpy
from cv_bridge import CvBridge
from geometry_msgs.msg import Twist
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import String


class OperatorConsole(Node):
    def __init__(self) -> None:
        super().__init__('operator_console')

        self.declare_parameter('camera_topic', '/competition/annotated_image')
        self.declare_parameter('forward_speed', 0.25)
        self.declare_parameter('turn_speed', 0.7)
        self.declare_parameter('manual_command_timeout', 0.30)
        self.declare_parameter('window_name', 'M.I.A Competition Camera')

        camera_topic = str(self.get_parameter('camera_topic').value)
        self.forward_speed = float(self.get_parameter('forward_speed').value)
        self.turn_speed = float(self.get_parameter('turn_speed').value)
        self.command_timeout = float(self.get_parameter('manual_command_timeout').value)
        self.window_name = str(self.get_parameter('window_name').value)

        self.bridge = CvBridge()
        self.last_frame = None
        self.last_key_time = self.get_clock().now()
        self.manual_twist = Twist()

        self.state_pub = self.create_publisher(String, '/competition/operator_command', 10)
        self.manual_pub = self.create_publisher(Twist, '/competition/manual_cmd_vel', 10)
        self.create_subscription(Image, camera_topic, self.image_callback, 10)
        self.timer = self.create_timer(0.05, self.update)

        cv2.namedWindow(self.window_name, cv2.WINDOW_NORMAL)
        self.get_logger().info(
            'Operator ready: ENTER=start auto, M=manual/green card, '
            'WASD=drive, SPACE=stop, R=reset, Q=quit.'
        )

    def image_callback(self, msg: Image) -> None:
        try:
            self.last_frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as exc:  # pylint: disable=broad-except
            self.get_logger().error(f'Camera conversion failed: {exc}')

    def publish_operator_command(self, command: str) -> None:
        msg = String()
        msg.data = command
        self.state_pub.publish(msg)
        self.get_logger().info(f'Operator command: {command}')

    def publish_manual_twist(self, linear: float = 0.0, angular: float = 0.0) -> None:
        msg = Twist()
        msg.linear.x = linear
        msg.angular.z = angular
        self.manual_pub.publish(msg)
        self.manual_twist = msg
        self.last_key_time = self.get_clock().now()

    def update(self) -> None:
        if self.last_frame is not None:
            frame = self.last_frame.copy()
            cv2.putText(
                frame,
                'ENTER: AUTO | M: MANUAL | WASD: DRIVE | SPACE: STOP | R: RESET',
                (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (255, 255, 255),
                2,
            )
            cv2.imshow(self.window_name, frame)

        key = cv2.waitKey(1) & 0xFF
        if key in (27, ord('q')):
            self.publish_operator_command('STOP')
            self.publish_manual_twist()
            raise SystemExit

        if key in (10, 13):  # Enter
            self.publish_operator_command('START_AUTO')
            self.publish_manual_twist()
        elif key in (ord('m'), ord('M')):
            self.publish_operator_command('MANUAL')
            self.publish_manual_twist()
        elif key == 32:  # Space
            self.publish_operator_command('STOP')
            self.publish_manual_twist()
        elif key in (ord('r'), ord('R')):
            self.publish_operator_command('RESET')
            self.publish_manual_twist()
        elif key in (ord('w'), ord('W')):
            self.publish_manual_twist(linear=self.forward_speed)
        elif key in (ord('s'), ord('S')):
            self.publish_manual_twist(linear=-self.forward_speed)
        elif key in (ord('a'), ord('A')):
            self.publish_manual_twist(angular=self.turn_speed)
        elif key in (ord('d'), ord('D')):
            self.publish_manual_twist(angular=-self.turn_speed)

        age = (self.get_clock().now() - self.last_key_time).nanoseconds / 1e9
        if age > self.command_timeout and (
            abs(self.manual_twist.linear.x) > 1e-6 or abs(self.manual_twist.angular.z) > 1e-6
        ):
            self.publish_manual_twist()

    def destroy_node(self):
        try:
            self.publish_manual_twist()
            cv2.destroyAllWindows()
        except Exception:
            pass
        super().destroy_node()


def main(args=None) -> None:
    rclpy.init(args=args)
    node = OperatorConsole()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
