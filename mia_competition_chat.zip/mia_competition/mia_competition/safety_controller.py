#!/usr/bin/env python3
"""Ultrasonic safety layer for both autonomous and manual motion."""

import math

import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node
from std_msgs.msg import Float32


class SafetyController(Node):
    def __init__(self) -> None:
        super().__init__('safety_controller')

        self.declare_parameter('ultrasonic_min_distance_m', 0.35)
        self.declare_parameter('ultrasonic_timeout_s', 0.50)
        self.declare_parameter('allow_reverse_when_blocked', True)
        self.declare_parameter('ultrasonic_scale_to_meters', 1.0)

        self.min_distance = float(self.get_parameter('ultrasonic_min_distance_m').value)
        self.timeout = float(self.get_parameter('ultrasonic_timeout_s').value)
        self.allow_reverse = bool(self.get_parameter('allow_reverse_when_blocked').value)
        self.scale_to_m = float(self.get_parameter('ultrasonic_scale_to_meters').value)

        self.latest_distance = None
        self.last_sensor_time = None
        self.pending = Twist()

        self.create_subscription(Twist, '/competition/cmd_vel', self.command_callback, 10)
        self.create_subscription(Float32, '/ultrasonic_distance', self.ultrasonic_callback, 10)
        self.pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.timer = self.create_timer(0.02, self.publish_safe_command)

    def ultrasonic_callback(self, msg: Float32) -> None:
        value = float(msg.data) * self.scale_to_m
        if math.isfinite(value) and value >= 0.0:
            self.latest_distance = value
            self.last_sensor_time = self.get_clock().now()

    def command_callback(self, msg: Twist) -> None:
        self.pending = msg

    def publish_safe_command(self) -> None:
        output = Twist()
        output.linear.x = self.pending.linear.x
        output.angular.z = self.pending.angular.z

        if self.pending.linear.x > 0.0:
            sensor_is_fresh = False
            if self.last_sensor_time is not None:
                age = (self.get_clock().now() - self.last_sensor_time).nanoseconds / 1e9
                sensor_is_fresh = age <= self.timeout

            # Fail safe for forward motion: stale/no ultrasonic information
            # means forward motion is blocked.
            if not sensor_is_fresh:
                output.linear.x = 0.0
            elif self.latest_distance is not None and self.latest_distance < self.min_distance:
                output.linear.x = 0.0

        elif self.pending.linear.x < 0.0 and not self.allow_reverse:
            output.linear.x = 0.0

        self.pub.publish(output)


def main(args=None) -> None:
    rclpy.init(args=args)
    node = SafetyController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
