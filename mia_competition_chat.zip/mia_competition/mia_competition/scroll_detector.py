#!/usr/bin/env python3
"""YOLO scroll detector for the real competition robot.

Subscribes to the robot camera, runs an Ultralytics YOLO model, and publishes:
  /competition/detections       std_msgs/String containing JSON detections
  /competition/annotated_image  sensor_msgs/Image

The package does not include a trained model. Put the trained .pt file on the
robot and set model_path in config/competition.yaml.
"""

import json
import os
from typing import List, Dict

from ament_index_python.packages import get_package_share_directory

import cv2
import rclpy
from cv_bridge import CvBridge
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import String


class ScrollDetector(Node):
    def __init__(self) -> None:
        super().__init__('scroll_detector')

        self.declare_parameter('image_topic', '/mono/image')
        self.declare_parameter('model_path', 'models/best.pt')
        self.declare_parameter('confidence_threshold', 0.55)
        self.declare_parameter('iou_threshold', 0.45)
        self.declare_parameter('image_width_limit', 0)
        self.declare_parameter('publish_annotated_image', True)

        image_topic = str(self.get_parameter('image_topic').value)
        self.model_path = str(self.get_parameter('model_path').value)
        self.confidence_threshold = float(self.get_parameter('confidence_threshold').value)
        self.iou_threshold = float(self.get_parameter('iou_threshold').value)
        self.width_limit = int(self.get_parameter('image_width_limit').value)
        self.publish_annotated = bool(self.get_parameter('publish_annotated_image').value)

        self.bridge = CvBridge()
        self.model = None
        self.model_ready = False

        self.detection_pub = self.create_publisher(String, '/competition/detections', 10)
        self.image_pub = self.create_publisher(Image, '/competition/annotated_image', 10)
        self.subscription = self.create_subscription(
            Image, image_topic, self.image_callback, 10
        )

        self._load_model()

    def _load_model(self) -> None:
        path = os.path.expanduser(self.model_path)
        if not os.path.isabs(path):
            path = os.path.join(get_package_share_directory('mia_competition'), path)

        if not os.path.isfile(path):
            self.get_logger().warn(
                f'YOLO model not found: {path}. '
                'Detector will publish empty detections until the model is supplied.'
            )
            return

        try:
            from ultralytics import YOLO
        except ImportError:
            self.get_logger().error(
                'Ultralytics is not installed. Run: python3 -m pip install ultralytics'
            )
            return

        try:
            self.model = YOLO(path)
            self.model_ready = True
            self.get_logger().info(f'Loaded YOLO model: {path}')
        except Exception as exc:  # pylint: disable=broad-except
            self.get_logger().error(f'Could not load YOLO model: {exc}')

    def image_callback(self, msg: Image) -> None:
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as exc:  # pylint: disable=broad-except
            self.get_logger().error(f'Could not convert image: {exc}')
            return

        if self.width_limit > 0 and frame.shape[1] > self.width_limit:
            scale = self.width_limit / frame.shape[1]
            frame = cv2.resize(frame, None, fx=scale, fy=scale)

        detections: List[Dict] = []
        annotated = frame.copy()

        if self.model_ready:
            try:
                results = self.model.predict(
                    source=frame,
                    conf=self.confidence_threshold,
                    iou=self.iou_threshold,
                    verbose=False,
                )
                result = results[0]
                names = result.names

                if result.boxes is not None:
                    for box in result.boxes:
                        confidence = float(box.conf[0].item())
                        class_id = int(box.cls[0].item())
                        x1, y1, x2, y2 = [float(v) for v in box.xyxy[0].tolist()]
                        cx = (x1 + x2) / 2.0
                        cy = (y1 + y2) / 2.0
                        width = max(0.0, x2 - x1)
                        height = max(0.0, y2 - y1)
                        class_name = str(names[class_id])

                        detections.append({
                            'class_id': class_id,
                            'class_name': class_name,
                            'confidence': confidence,
                            'x1': x1,
                            'y1': y1,
                            'x2': x2,
                            'y2': y2,
                            'center_x': cx,
                            'center_y': cy,
                            'width': width,
                            'height': height,
                        })

                        cv2.rectangle(
                            annotated,
                            (int(x1), int(y1)),
                            (int(x2), int(y2)),
                            (0, 255, 0),
                            2,
                        )
                        label = f'{class_name} {confidence:.2f}'
                        cv2.putText(
                            annotated,
                            label,
                            (int(x1), max(20, int(y1) - 8)),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.6,
                            (0, 255, 0),
                            2,
                        )
            except Exception as exc:  # pylint: disable=broad-except
                self.get_logger().error(f'YOLO inference failed: {exc}')

        detection_message = String()
        detection_message.data = json.dumps({
            'stamp_sec': msg.header.stamp.sec,
            'stamp_nanosec': msg.header.stamp.nanosec,
            'image_width': int(frame.shape[1]),
            'image_height': int(frame.shape[0]),
            'detections': detections,
        })
        self.detection_pub.publish(detection_message)

        if self.publish_annotated:
            try:
                annotated_msg = self.bridge.cv2_to_imgmsg(annotated, encoding='bgr8')
                annotated_msg.header = msg.header
                self.image_pub.publish(annotated_msg)
            except Exception as exc:  # pylint: disable=broad-except
                self.get_logger().error(f'Could not publish annotated image: {exc}')


def main(args=None) -> None:
    rclpy.init(args=args)
    node = ScrollDetector()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
