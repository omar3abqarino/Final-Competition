#!/usr/bin/env python3
"""TESTING ONLY: publish a short slow forward command to /cmd_vel.

Secure/lift the robot before running this file.
"""

import time

import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node


class CmdVelTest(Node):
    def __init__(self) -> None:
        super().__init__('test_cmd_vel_forward')
        self.pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.start = time.monotonic()
        self.timer = self.create_timer(0.05, self.loop)

    def loop(self) -> None:
        elapsed = time.monotonic() - self.start
        msg = Twist()
        if elapsed < 1.0:
            msg.linear.x = 0.05
        self.pub.publish(msg)
        if elapsed >= 1.2:
            raise SystemExit


def main(args=None) -> None:
    rclpy.init(args=args)
    node = CmdVelTest()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        stop = Twist()
        node.pub.publish(stop)
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
