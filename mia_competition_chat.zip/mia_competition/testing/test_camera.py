#!/usr/bin/env python3
"""TESTING ONLY: display the raw competition camera."""

import cv2
import rclpy
from cv_bridge import CvBridge
from rclpy.node import Node
from sensor_msgs.msg import Image


class CameraTest(Node):
    def __init__(self) -> None:
        super().__init__('test_camera')
        self.bridge = CvBridge()
        self.frame = None
        self.create_subscription(Image, '/mono/image', self.callback, 10)
        self.create_timer(0.03, self.display)
        cv2.namedWindow('Camera Test', cv2.WINDOW_NORMAL)

    def callback(self, msg: Image) -> None:
        try:
            self.frame = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        except Exception as exc:  # pylint: disable=broad-except
            self.get_logger().error(str(exc))

    def display(self) -> None:
        if self.frame is not None:
            cv2.imshow('Camera Test', self.frame)
        key = cv2.waitKey(1) & 0xFF
        if key in (27, ord('q')):
            raise SystemExit


def main(args=None) -> None:
    rclpy.init(args=args)
    node = CameraTest()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        cv2.destroyAllWindows()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
