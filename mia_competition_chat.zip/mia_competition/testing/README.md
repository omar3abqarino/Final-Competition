# Testing-only files

These files are **not part of the competition launch**. They are kept separate
so nobody accidentally launches a test publisher during an official match.

Run them after sourcing ROS and your workspace, one at a time.

## Camera test

```bash
ros2 run mia_competition test_camera
```

The test displays `/mono/image` in an OpenCV window.

## Ultrasonic test

```bash
ros2 run mia_competition test_ultrasonic
```

This prints `/ultrasonic_distance` values. The competition package assumes a
`std_msgs/msg/Float32` message for this topic.

## cmd_vel test

```bash
ros2 run mia_competition test_cmd_vel_forward
```

This sends a very slow forward command for a short time. **Lift the robot's
wheels or otherwise secure it before using this test.**
