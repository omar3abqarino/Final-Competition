#!/usr/bin/env python3
"""TESTING ONLY: print Float32 ultrasonic readings."""

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32


class UltrasonicTest(Node):
    def __init__(self) -> None:
        super().__init__('test_ultrasonic')
        self.create_subscription(Float32, '/ultrasonic_distance', self.callback, 10)

    def callback(self, msg: Float32) -> None:
        self.get_logger().info(f'ultrasonic_distance = {msg.data:.3f}')


def main(args=None) -> None:
    rclpy.init(args=args)
    node = UltrasonicTest()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
