# M.I.A Competition Package — Real Competition Code

This package is intended for the **real M.I.A Piston Cup competition robot** described in the supplied rulebook. It does not contain Gazebo, fake robots, or simulation launch files.

The rulebook defines a one-vs-one match with two 5-minute rounds. Each half contains two scrolls that must be detected autonomously. After the judge raises the green card, the pilot manually pushes the center scroll into the opponent's arena and then returns to the start zone. The documented robot interfaces are `/mono/image`, `/ultrasonic_distance`, and `/cmd_vel`. fileciteturn0file0L93-L129 fileciteturn0file0L163-L184

## Design decisions used in this package

- ROS 2 Jazzy / Python.
- No odometry, TF, IMU, or wheel feedback is assumed.
- `/ultrasonic_distance` is assumed to use `std_msgs/msg/Float32` for the initial implementation.
- `/mono/image` is assumed to use `sensor_msgs/msg/Image`.
- Ultralytics YOLO is used for scroll detection.
- The model can have multiple classes. Every class is treated as a possible scroll symbol.
- Autonomous search rotates in place by a calibrated angle, then rotates back by the same angle. If no new scroll is confirmed, the robot moves forward for a short calibrated time and repeats.
- The search is divided into Zone A and Zone B through parameters.
- A detected scroll is confirmed over several frames and the robot stops rather than deliberately approaching it.
- After both scrolls are confirmed the robot waits for the green-card/manual command.
- Pressing `M` switches directly from autonomous/waiting mode to manual driving. There is no separate push/return command: both are manual driving phases.
- Manual driving uses `W/A/S/D`.
- `SPACE` is an emergency stop, `R` resets the competition state, and `ENTER` starts a new autonomous run.
- The operator sees a live camera window; there is no complicated GUI.
- Testing-only files are kept in `testing/` and are not launched by the competition launch file.

## Package layout

```text
mia_competition/
├── mia_competition/
│   ├── competition_manager.py   # Main match state machine + autonomous search
│   ├── scroll_detector.py       # Ultralytics YOLO + annotated camera
│   ├── operator_console.py      # Live camera + keyboard control
│   └── safety_controller.py     # Ultrasonic protection before /cmd_vel
├── config/
│   └── competition.yaml         # Main tuning parameters
├── launch/
│   └── competition.launch.py    # Real competition launch
├── models/
│   └── README.md                # Where the trained YOLO model goes
├── testing/                     # TESTING ONLY
│   ├── test_camera.py
│   ├── test_ultrasonic.py
│   └── test_cmd_vel_forward.py
└── README.md
```

## ROS topic flow

```text
/mono/image
     |
     v
scroll_detector
     |
     +--> /competition/detections
     +--> /competition/annotated_image

operator_console
     |
     +--> /competition/operator_command
     +--> /competition/manual_cmd_vel

competition_manager
     |
     +--> /competition/cmd_vel

/ultrasonic_distance ------------------+
                                      |
                                      v
                              safety_controller
                                      |
                                      v
                                   /cmd_vel
```

The important point is that competition logic does **not** publish directly to the real `/cmd_vel`. Everything passes through the ultrasonic safety layer.

## Keys

| Key | Function |
|---|---|
| `ENTER` | Start a new autonomous search |
| `M` | Switch from autonomous/waiting to manual mode (green-card action) |
| `W` | Forward |
| `S` | Reverse |
| `A` | Turn left |
| `D` | Turn right |
| `SPACE` | Emergency stop |
| `R` | Reset to idle |
| `Q` / `ESC` | Close operator program and stop |

Manual commands time out after a short interval. This means losing keyboard input does not leave a continuous motion command running.

## 1. Install ROS package dependencies

On the robot computer, source ROS 2 Jazzy first:

```bash
source /opt/ros/jazzy/setup.bash
```

Install the Python packages that are not normally provided by the robot's ROS image:

```bash
python3 -m pip install ultralytics
```

`cv_bridge`, OpenCV, and the ROS Python packages should come from the ROS installation. If a package is missing, install the corresponding ROS Jazzy Debian package rather than changing the competition code.

## 2. Build

Copy the package into your workspace `src` directory:

```bash
cd ~/YOUR_WORKSPACE/src
# place mia_competition/ here
cd ..
source /opt/ros/jazzy/setup.bash
colcon build --symlink-install
source install/setup.bash
```

## 3. Add the trained YOLO model later

The default model path is:

```text
models/best.pt
```

Place the trained model there, rebuild, and source the workspace again. Alternatively, change `model_path` in `config/competition.yaml` to an absolute `.pt` path.

No model is included in this package yet.

## 4. Launch the actual competition software

After the robot's own low-level code is already running:

```bash
source /opt/ros/jazzy/setup.bash
source ~/YOUR_WORKSPACE/install/setup.bash
ros2 launch mia_competition competition.launch.py
```

The package expects the robot to already provide:

```text
/mono/image
/ultrasonic_distance
/cmd_vel
```

## 5. Competition operation

### Before the round

Place the robot in its official start zone. Start the competition package and watch the live camera window.

### Autonomous phase

Press:

```text
ENTER
```

The manager enters `AUTONOMOUS` and performs the configured search.

The search sequence is approximately:

```text
rotate +angle
      |
      v
scan YOLO detections
      |
rotate -angle
      |
      v
return to starting orientation
      |
      v
move forward a short time
      |
      v
repeat
```

If a scroll is confidently detected for enough consecutive frames, the robot stops and registers it. It does not intentionally drive close to the scroll.

After two scrolls are registered, the robot stops and waits.

### Green card / manual phase

When the judge gives the green card, press:

```text
M
```

This immediately changes the manager to `MANUAL`. From that point the pilot uses:

```text
W A S D
```

for the entire manual push and return portion of the match.

There is deliberately **no separate software event for "pushed" or "returning"** because the documented competition interfaces do not provide enough information to reliably infer the position of the third scroll or the exact start-zone boundary.

### Emergency stop

Press `SPACE`.

### Reset

Press `R` before starting a new run or when the judges authorize a reset.

## 6. Important tuning parameters

The most important parameters are in `config/competition.yaml`.

### Scan angle

```yaml
scan_angle_deg: 120.0
rotation_speed_rad_s: 0.70
```

The robot estimates the required rotation time as:

```text
rotation_time = angle / angular_speed
```

Because there is no odometry or heading sensor, this is a **calibrated timed rotation**, not a feedback-controlled angle. Test this on the actual robot and tune `rotation_speed_rad_s` and `scan_angle_deg`.

### Forward movement

```yaml
forward_speed: 0.20
forward_step_time_s: 1.00
```

These determine how far the robot advances between scan positions. They should be tuned so that the robot covers the arena without making the search too slow or approaching a previously detected scroll unnecessarily.

### YOLO confirmation

```yaml
detection_confirm_frames: 5
detection_min_confidence: 0.55
```

A single YOLO frame does not count as a successful detection. The same candidate must remain sufficiently stable for several frames.

### Ultrasonic safety

```yaml
ultrasonic_min_distance_m: 0.35
ultrasonic_timeout_s: 0.50
ultrasonic_scale_to_meters: 1.0
```

The default assumes the Float32 distance is already in meters. If the robot publishes centimeters, change:

```yaml
ultrasonic_scale_to_meters: 0.01
```

Do not use the default stopping distance blindly. Measure how quickly the real robot stops and tune it before the competition.

## 7. Testing-only files

The official launch file does not start anything in `testing/`.

Camera test:

```bash
ros2 run mia_competition test_camera
```

Ultrasonic test:

```bash
ros2 run mia_competition test_ultrasonic
```

Very slow `/cmd_vel` test:

```bash
ros2 run mia_competition test_cmd_vel_forward
```

Secure/lift the robot before running the motion test.

## 8. Known limitation that must be tested

The robot has no localization feedback according to the current competition setup. Therefore the search system is intentionally simple and uses timed motion. That is the correct behavior for the information currently available, but it means the following values must be calibrated on the real competition robot:

- rotation timing
- forward movement timing
- ultrasonic stopping distance
- YOLO confidence threshold
- YOLO confirmation frame count
- number of scan positions per zone

Do **not** treat simulation timing or a different robot as a final calibration.

## 9. Match strategy reflected in the code

The competition rewards reliable autonomous detection heavily: correct detection is 15 points per scroll, autonomous detection is 45 points, pushing the center scroll is 20 points, and returning to the start zone is 25 points. Hitting scrolls or walls costs points, while the fastest-round bonus is only +10. fileciteturn0file0L146-L162

The package therefore prioritizes:

1. reliable autonomous detection without intentionally touching the scroll,
2. safe controlled motion,
3. immediate transition to manual mode after the green card,
4. simple manual control for the push and return,
5. easy parameter tuning rather than a large navigation framework.
