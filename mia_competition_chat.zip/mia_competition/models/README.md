# YOLO model

The competition detector expects an Ultralytics YOLO `.pt` model.

For the default configuration, place the trained model here as:

    models/best.pt

The package does not include the trained model yet because the dataset/model is
not ready.

The model can contain multiple classes. The detector forwards every class name
from the model. The competition manager treats detections from all classes as
scroll candidates because the two physical scrolls can carry different symbols.

Required Python package on the robot:

    python3 -m pip install ultralytics
