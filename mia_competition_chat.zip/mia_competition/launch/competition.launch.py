#!/usr/bin/env python3

from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os


def generate_launch_description():
    package_share = get_package_share_directory('mia_competition')
    config = os.path.join(package_share, 'config', 'competition.yaml')

    return LaunchDescription([
        Node(
            package='mia_competition',
            executable='scroll_detector',
            name='scroll_detector',
            output='screen',
            parameters=[config],
        ),
        Node(
            package='mia_competition',
            executable='competition_manager',
            name='competition_manager',
            output='screen',
            parameters=[config],
        ),
        Node(
            package='mia_competition',
            executable='safety_controller',
            name='safety_controller',
            output='screen',
            parameters=[config],
        ),
        Node(
            package='mia_competition',
            executable='operator_console',
            name='operator_console',
            output='screen',
            parameters=[config],
        ),
    ])
