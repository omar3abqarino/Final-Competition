#!/usr/bin/env python3
"""pilot_remote_control.py

Runs on the PILOT'S laptop -- a separate machine from the Runner's, with
no ROS2 install required at all. Just needs Python 3 + opencv-python
(see requirements.txt).

What it does:
  1. Opens the Runner's MJPEG video stream (video_stream_server_node) in a
     window, so the Pilot can see through the mono camera.
  2. Reads keyboard input and sends short text commands over a TCP socket
     to teleop_bridge_node on the Runner's laptop.

Controls (differential drive):
    W / S   - forward / backward
    A / D   - turn left / turn right
    ESC     - quit

Safety behaviour: every loop iteration sends either the currently-held
drive key or "STOP" if none is pressed. If the connection drops, the
script keeps retrying to reconnect, and teleop_bridge_node's own watchdog
will stop the robot if no command arrives for half a second.

Usage:
    python3 pilot_remote_control.py --host 192.168.1.50 --port 9999 \\
        --stream-url http://192.168.1.50:8080/video_feed
"""
import argparse
import socket
import time

import cv2

KEY_TO_COMMAND = {
    ord('w'): 'W', ord('W'): 'W',
    ord('s'): 'S', ord('S'): 'S',
    ord('a'): 'A', ord('A'): 'A',
    ord('d'): 'D', ord('D'): 'D',
}

ESC_KEY = 27


def connect(host, port):
    while True:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2.0)
            sock.connect((host, port))
            sock.settimeout(None)
            print(f'[pilot] Connected to Runner teleop bridge at {host}:{port}')
            return sock
        except OSError as exc:
            print(f'[pilot] Could not connect ({exc}); retrying in 1s...')
            time.sleep(1.0)


def main():
    parser = argparse.ArgumentParser(description='MIA Piston Cup - Pilot remote control station')
    parser.add_argument('--host', required=True, help="Runner laptop's IP address")
    parser.add_argument('--port', type=int, default=9999, help='teleop_bridge_node TCP port')
    parser.add_argument('--stream-url', required=True,
                         help="Runner laptop's MJPEG stream URL, e.g. http://<ip>:8080/video_feed")
    args = parser.parse_args()

    print('[pilot] Connecting to video stream (this can take a couple seconds)...')
    cap = cv2.VideoCapture(args.stream_url)

    sock = connect(args.host, args.port)

    window_name = 'MIA Piston Cup - Pilot View (mono cam)'
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)

    print('[pilot] Controls: W/S forward-back, A/D turn left-right, ESC to quit.')

    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                # Stream hiccup - try to reopen it.
                cap.release()
                time.sleep(0.5)
                cap = cv2.VideoCapture(args.stream_url)
                continue

            cv2.imshow(window_name, frame)
            key = cv2.waitKey(30) & 0xFF

            if key == ESC_KEY:
                break

            command = KEY_TO_COMMAND.get(key, 'STOP')

            try:
                sock.sendall((command + '\n').encode('utf-8'))
            except OSError:
                print('[pilot] Connection to Runner lost. Reconnecting...')
                sock.close()
                sock = connect(args.host, args.port)

    finally:
        try:
            sock.sendall(b'STOP\n')
        except OSError:
            pass
        sock.close()
        cap.release()
        cv2.destroyAllWindows()


if __name__ == '__main__':
    main()
