# MIA Piston Cup - Competition Package

ROS2 (Jazzy Jalisco) package + standalone Pilot station script for the
MIA Robotics Electrical Training 2026/27 Final Competition.

## What's in here

```
mia_pistoncup/              <- ROS2 package, runs on the RUNNER's laptop
  mia_pistoncup/
    robot_state.py          <- shared state name constants (IDLE/SEARCHING/...)
    ultrasonic_safety_node.py <- COMPETITION: single gateway, only writer of /cmd_vel
    detection_node.py       <- COMPETITION: YOLO 2-class scroll detection
    search_controller_node.py <- COMPETITION: autonomous rotate-sweep + forward creep
    state_machine_node.py   <- COMPETITION: Runner console + /robot_state publisher
    teleop_bridge_node.py   <- COMPETITION: receives Pilot's drive commands over TCP
    video_stream_server_node.py <- COMPETITION: streams /mono/image to the Pilot over HTTP
    tools/                  <- TESTING ONLY - never runs during a round, see section 6
      motion_test.py        <- timed forward/rotate calibration (no odometry needed)
      ultrasonic_monitor.py <- read-only sensor check, never commands the robot
  launch/
    runner_launch.py        <- THE competition launch: all 6 real nodes above together
    testing/                <- TESTING ONLY launch files, see section 6
      test_hardware.launch.py
      test_manual_drive.launch.py
      test_motion_calibration.launch.py
  config/params.yaml        <- every tunable number in one place
  models/                   <- drop your trained best.pt here
pilot_station/               <- runs on the PILOT's separate laptop (no ROS2 needed)
  pilot_remote_control.py
  requirements.txt
```

## How the two phases map to this code

| Rulebook phase | Who | Node(s) responsible |
|---|---|---|
| Autonomous scroll detection | Runner | `detection_node` (sees), `search_controller_node` (moves) |
| Runner shows judge the confirmed detection | Runner | `state_machine_node` prints the message, Runner types `green` after judge OKs it |
| Manual push + return | Pilot | `pilot_remote_control.py` (Pilot's laptop) -> `teleop_bridge_node` (Runner's laptop) |

Everything is gated by a single `/robot_state` topic so only one "driver"
(search controller or teleop bridge) is ever allowed to move the robot at
a time -- see `mia_pistoncup/robot_state.py` for the full state diagram.

On top of that, every node's motion request goes through one more gate
before it reaches the real robot:

```
AUTONOMOUS / TELEOP / EMERGENCY STOP
        |
        v
/cmd_vel_requested
        |
        v
ultrasonic_safety_node   <- the ONLY node that publishes /cmd_vel
        |
        v
/cmd_vel
        |
        v
REAL ROBOT
```

`search_controller_node`, `teleop_bridge_node`, and `state_machine_node`
(for its emergency stop) all publish what they *want* to do on
`/cmd_vel_requested`. `ultrasonic_safety_node` is the single place that
turns that into the real `/cmd_vel`, clamping or zeroing forward speed if
the ultrasonic sensor says something is too close (or has gone silent).
That means there's exactly one node to check if the robot ever drives
into something, no matter which controller was driving at the time.

---

## 1. Assumptions this package makes

- The **low-level driver is already running** and provides:
  - `/cmd_vel` (geometry_msgs/Twist) - subscribed by the motor controller. `linear.x`=forward/back, `angular.z`=turn left/right (differential drive). **Only `ultrasonic_safety_node` publishes to this topic** - everything else publishes to `/cmd_vel_requested` instead (see the command-path diagram above).
  - `/mono/image` (sensor_msgs/Image) - published by the camera driver.
  - `/ultrasonic_distance` (**std_msgs/Float32**, meters) - published by the ultrasonic driver.
    **If your driver actually publishes `sensor_msgs/Range` instead**, open
    `ultrasonic_safety_node.py` and `search_controller_node.py`, change the
    `Float32` import/subscription to `Range` in both, and read `msg.range`
    instead of `msg.data`. Nothing else needs to change.
- Runner's laptop is connected to the robot via USB and runs the full ROS2 workspace.
- Pilot's laptop is a **separate machine**, connected over the same WiFi network, with no ROS2 install at all.

## 2. One-time setup (Runner's laptop)

```bash
# Inside your ROS2 workspace, e.g. ~/ros2_ws/src
cp -r mia_pistoncup ~/ros2_ws/src/

cd ~/ros2_ws
rosdep install --from-paths src --ignore-src -r -y
pip install ultralytics flask   # not available as rosdep packages

colcon build --packages-select mia_pistoncup
source install/setup.bash
```

Drop your trained model at `mia_pistoncup/models/best.pt` (see
`mia_pistoncup/models/README.md`). Until it's there, `detection_node` will
log a clear error and simply stay idle instead of crashing.

## 3. One-time setup (Pilot's laptop)

```bash
cd pilot_station
python3 -m venv venv        # optional but recommended
source venv/bin/activate
pip install -r requirements.txt
```

## 4. Find the Runner laptop's IP address

On the Runner's laptop (both machines must be on the same WiFi network):

```bash
ip addr show   # look for the WiFi interface, e.g. wlan0 -> 192.168.1.50
```

## 5. Running it (competition day)

**On the Runner's laptop** (after your low-level driver / camera driver are already running):

```bash
source ~/ros2_ws/install/setup.bash
ros2 launch mia_pistoncup runner_launch.py
```

This starts the safety gateway, detection, search control, the state
machine console, the teleop bridge, and the video stream server all
together. Watch this terminal -- it's where the Runner types commands and
sees status messages.

**On the Pilot's laptop:**

```bash
cd pilot_station
source venv/bin/activate
python3 pilot_remote_control.py \
  --host 192.168.1.50 \
  --port 9999 \
  --stream-url http://192.168.1.50:8080/video_feed
```

(Replace `192.168.1.50` with the Runner laptop's actual IP from step 4.)
A window opens showing the mono camera feed. Controls: `W/S` forward-back,
`A/D` turn left/right, `ESC` to quit.

## 6. Competition code vs. testing tools

Everything under `mia_pistoncup/mia_pistoncup/tools/` and
`mia_pistoncup/launch/testing/` is a **diagnostic/calibration aid**, never
part of the actual match stack. They're kept in separate folders (and
clearly labeled in the file tree above) on purpose, so it's never
ambiguous which files to trust for the real match: anything outside
`tools/`/`testing/` is competition code, and `runner_launch.py` is the
one launch file you run on match day.

**Recommended real-robot bring-up order**, each step building on the last:

1. Check the three real topics exist:
   ```bash
   ros2 topic info /mono/image
   ros2 topic info /ultrasonic_distance
   ros2 topic info /cmd_vel
   ```
2. **Read-only sensor check** (never commands the robot):
   ```bash
   ros2 launch mia_pistoncup test_hardware.launch.py
   ```
   Confirms the ultrasonic sensor is wired up and `ultrasonic_safety_node`
   is gating correctly, before anything is allowed to move.
3. **Small, calibrated motion tests** (always start tiny, in a clear area):
   ```bash
   ros2 launch mia_pistoncup test_motion_calibration.launch.py \
     mode:=forward magnitude:=0.20 linear_speed_mps:=0.15 auto_start:=true
   ```
   Measure the actual distance/angle moved and compare to `magnitude` --
   this is how you calibrate `search_controller_node`'s
   `step_rotate_duration`, `angular_speed`, `forward_duration`, and
   `linear_speed` parameters in `config/params.yaml`.
4. **Manual drive + camera only**, no detection or state machine yet:
   ```bash
   ros2 launch mia_pistoncup test_manual_drive.launch.py
   ```
5. Only once 1-4 look good: run the real thing.
   ```bash
   ros2 launch mia_pistoncup runner_launch.py
   ```

## 7. Running a round

1. Runner's terminal shows the console menu. Once everything is set up and the robot is at its start zone, Runner types:
   ```
   start
   ```
   The robot begins its rotate-sweep autonomous search.
2. When both scrolls have been confidently seen for enough consecutive
   frames, the robot **stops automatically** and the Runner's terminal
   prints a clear "show this to the judge" message.
3. Runner shows the judge; judge raises the green card. Runner types:
   ```
   green
   ```
4. The Pilot now has control. They push the third scroll into the
   opponent's arena and drive back to the start zone using the keyboard.
5. After the round (win, loss, or reset needed), Runner types:
   ```
   reset
   ```
   to return to `IDLE` and get ready for the next round. `reset` also
   immediately force-stops the robot, so use it any time something looks wrong.

## 8. Tuning before the event

Everything worth tuning lives in `mia_pistoncup/config/params.yaml` -
no code edits needed for these:

- **Detection feels too jumpy/slow to confirm** -> adjust
  `confidence_threshold` and `required_consecutive_frames` in `detection_node`.
- **Sweep rotates too far/not far enough per step** -> `step_rotate_duration`
  and `angular_speed` in `search_controller_node` (this is open-loop/timing-based,
  so it needs real on-robot testing to calibrate).
- **Forward creep too aggressive near walls** -> raise `min_wall_distance`
  (this is `search_controller_node`'s own planning check) and/or
  `stop_distance_m`/`slow_distance_m` (the actual safety clamp) in
  `ultrasonic_safety_node`.
- **Pilot's drive feels too slow/fast** -> `linear_speed` / `angular_speed`
  in `teleop_bridge_node`.
- **Video too laggy** -> lower `jpeg_quality` in `video_stream_server_node`
  (less bandwidth, faster, lower image quality).

Re-run `colcon build --packages-select mia_pistoncup` after editing
`params.yaml`, or just pass `params_file:=/path/to/your.yaml` at launch
if you keep multiple tuned versions around (e.g. one per playing surface).

## 9. Known simplifications (on purpose, to stay beginner-friendly)

- **No odometry** - the search pattern is time-based (rotate for X
  seconds ≈ Y degrees), not angle-based. It's not precise, but it doesn't
  need to be: the camera keeps scanning throughout, and the whole sweep
  cycle just repeats until it finds both scrolls.
- **No custom ROS2 interfaces package** - `/detection_status` and
  `/robot_state` are `std_msgs/String` (JSON for detection_status, plain
  text for robot_state) instead of custom `.msg` types, so there's nothing
  extra to generate/build.
- **Keyboard teleop, not a gamepad** - matches what you asked for; the
  watchdog stop-on-silence behavior keeps this safe even with basic input.
- **Plain TCP for the Pilot link, not ROS2-over-WiFi** - avoids depending
  on multicast/DDS discovery working over unknown competition WiFi.
- **One safety gateway, not per-node checks** - every controller requests
  motion on `/cmd_vel_requested`; only `ultrasonic_safety_node` writes the
  real `/cmd_vel`. One node to check, one set of safety parameters,
  regardless of which controller was driving.

## 10. Before the actual event - checklist

- [ ] `best.pt` trained and dropped into `mia_pistoncup/models/`
- [ ] Confirm `/ultrasonic_distance` message type matches (Float32 vs Range) - fix `ultrasonic_safety_node.py` and `search_controller_node.py` if needed
- [ ] Ran through the bring-up order in section 6 at least once on the real robot
- [ ] Full run-through: `start` -> confirm detection -> `green` -> Pilot drives -> `reset`
- [ ] Runner and Pilot laptops confirmed to reach each other's IP over the venue WiFi (test the video stream + a few keypresses **before** you're on the clock)
- [ ] Rotate-sweep timing calibrated with `test_motion_calibration.launch.py` on the actual practice field surface
- [ ] Class names in `config/params.yaml` (`class_a_name`/`class_b_name`) match your finalized dataset labels
