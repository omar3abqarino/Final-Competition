#!/usr/bin/env python3
"""teleop_bridge_node.py

Runs on the Runner's laptop (the one physically wired to the robot over
USB). Listens on a plain TCP socket for single-word drive commands sent by
pilot_station/pilot_remote_control.py, which runs on the Pilot's separate
laptop across the venue's WiFi.

Why a plain TCP socket instead of ROS2 networking between the two laptops?
Competition WiFi often blocks the multicast traffic ROS2/DDS relies on for
discovery, which can make cross-machine ROS2 topics unreliable right when
you need them most. A single TCP connection is simple, predictable, and
easy to debug under time pressure.

Commands understood (newline-delimited ASCII, case-insensitive):
    W  - drive forward
    S  - drive backward
    A  - turn left (counter-clockwise)
    D  - turn right (clockwise)
    STOP - all zero

This node does NOT write to /cmd_vel directly -- it publishes requested
motion on /cmd_vel_requested, and ultrasonic_safety_node is the single
gateway that turns that into the real /cmd_vel. Only requests non-zero
motion while /robot_state == TELEOP (so the Pilot physically cannot move
the robot during the autonomous phase).

SAFETY WATCHDOG: if no command is received for `command_timeout` seconds
(e.g. the Pilot's WiFi drops), the bridge automatically publishes a zero
Twist so the robot doesn't run away un-commanded.
"""
import socket
import threading
import time

import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node
from rclpy.qos import QoSDurabilityPolicy, QoSHistoryPolicy, QoSProfile
from std_msgs.msg import String

from mia_pistoncup import robot_state


class TeleopBridgeNode(Node):

    def __init__(self):
        super().__init__('teleop_bridge_node')

        self.declare_parameter('cmd_vel_topic', '/cmd_vel_requested')  # NOT /cmd_vel directly - see module docstring
        self.declare_parameter('tcp_host', '0.0.0.0')
        self.declare_parameter('tcp_port', 9999)
        self.declare_parameter('linear_speed', 0.3)
        self.declare_parameter('angular_speed', 0.6)
        self.declare_parameter('command_timeout', 0.5)  # seconds

        self.cmd_vel_topic = self.get_parameter('cmd_vel_topic').value
        self.tcp_host = self.get_parameter('tcp_host').value
        self.tcp_port = int(self.get_parameter('tcp_port').value)
        self.linear_speed = float(self.get_parameter('linear_speed').value)
        self.angular_speed = float(self.get_parameter('angular_speed').value)
        self.command_timeout = float(self.get_parameter('command_timeout').value)

        latched_qos = QoSProfile(
            depth=1,
            durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
            history=QoSHistoryPolicy.KEEP_LAST,
        )

        self.cmd_pub = self.create_publisher(Twist, self.cmd_vel_topic, 10)
        self.state_sub = self.create_subscription(
            String, '/robot_state', self.state_callback, latched_qos)

        self.current_state = robot_state.IDLE
        self.latest_command = 'STOP'
        self.last_command_time = time.monotonic()
        self._lock = threading.Lock()

        # Background TCP server thread (blocking sockets are fine here,
        # they never touch ROS2 objects directly except via the lock).
        self._server_thread = threading.Thread(target=self._run_server, daemon=True)
        self._server_thread.start()

        # Publish at a steady rate + enforce the watchdog.
        self.publish_timer = self.create_timer(0.05, self.publish_loop)

        self.get_logger().info(
            f'teleop_bridge_node listening on {self.tcp_host}:{self.tcp_port} '
            '(active only while /robot_state == TELEOP).'
        )

    def state_callback(self, msg: String):
        self.current_state = msg.data

    def _run_server(self):
        server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_sock.bind((self.tcp_host, self.tcp_port))
        server_sock.listen(1)

        while rclpy.ok():
            self.get_logger().info('Waiting for Pilot station to connect...')
            conn, addr = server_sock.accept()
            self.get_logger().info(f'Pilot station connected from {addr}')
            conn.settimeout(1.0)
            buffer = ''
            try:
                while rclpy.ok():
                    try:
                        data = conn.recv(64)
                    except socket.timeout:
                        continue
                    if not data:
                        break  # Pilot disconnected
                    buffer += data.decode('utf-8', errors='ignore')
                    while '\n' in buffer:
                        line, buffer = buffer.split('\n', 1)
                        cmd = line.strip().upper()
                        if cmd:
                            with self._lock:
                                self.latest_command = cmd
                                self.last_command_time = time.monotonic()
            except Exception as exc:  # noqa: BLE001
                self.get_logger().warn(f'Pilot connection error: {exc}')
            finally:
                conn.close()
                with self._lock:
                    self.latest_command = 'STOP'
                self.get_logger().warn('Pilot station disconnected. Robot stopped.')

    def publish_loop(self):
        with self._lock:
            cmd = self.latest_command
            age = time.monotonic() - self.last_command_time

        twist = Twist()

        if self.current_state == robot_state.TELEOP and age <= self.command_timeout:
            if cmd == 'W':
                twist.linear.x = self.linear_speed
            elif cmd == 'S':
                twist.linear.x = -self.linear_speed
            elif cmd == 'A':
                twist.angular.z = self.angular_speed
            elif cmd == 'D':
                twist.angular.z = -self.angular_speed
            # 'STOP' or unknown -> stays all zero

        # If not in TELEOP, or the watchdog timed out, twist stays all-zero.
        self.cmd_pub.publish(twist)


def main(args=None):
    rclpy.init(args=args)
    node = TeleopBridgeNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.cmd_pub.publish(Twist())
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
