#!/usr/bin/env python3
"""video_stream_server_node.py

Runs on the Runner's laptop. Subscribes to /mono/image and re-serves it as
a plain MJPEG HTTP stream, so the Pilot's separate laptop (on the same
WiFi network) can view it in a normal browser or with OpenCV's
VideoCapture, with no ROS2 networking required between the two machines.

View it manually at:  http://<runner_ip>:8080/          (simple <img> page)
Or the raw stream at:  http://<runner_ip>:8080/video_feed
"""
import threading

import cv2
import rclpy
from cv_bridge import CvBridge
from flask import Flask, Response
from rclpy.node import Node
from sensor_msgs.msg import Image


class VideoStreamServerNode(Node):

    def __init__(self):
        super().__init__('video_stream_server_node')

        self.declare_parameter('camera_topic', '/mono/image')
        self.declare_parameter('http_host', '0.0.0.0')
        self.declare_parameter('http_port', 8080)
        self.declare_parameter('jpeg_quality', 70)  # lower = less bandwidth, more latency-friendly

        self.camera_topic = self.get_parameter('camera_topic').value
        self.http_host = self.get_parameter('http_host').value
        self.http_port = int(self.get_parameter('http_port').value)
        self.jpeg_quality = int(self.get_parameter('jpeg_quality').value)

        self.bridge = CvBridge()
        self._frame_lock = threading.Lock()
        self._latest_jpeg = None

        self.image_sub = self.create_subscription(
            Image, self.camera_topic, self.image_callback, 10)

        self._flask_thread = threading.Thread(target=self._run_flask, daemon=True)
        self._flask_thread.start()

        self.get_logger().info(
            f'Streaming {self.camera_topic} at http://{self.http_host}:{self.http_port}/'
        )

    def image_callback(self, msg: Image):
        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        ok, jpeg = cv2.imencode(
            '.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), self.jpeg_quality])
        if ok:
            with self._frame_lock:
                self._latest_jpeg = jpeg.tobytes()

    def _mjpeg_generator(self):
        boundary = b'--frame'
        while rclpy.ok():
            with self._frame_lock:
                frame = self._latest_jpeg
            if frame is not None:
                yield (boundary + b'\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
            # A tiny sleep avoids a busy loop if no frames have arrived yet.
            else:
                import time
                time.sleep(0.05)

    def _run_flask(self):
        app = Flask(__name__)

        @app.route('/')
        def index():
            return (
                '<html><body style="margin:0;background:#000;">'
                '<img src="/video_feed" style="width:100%;height:auto;" />'
                '</body></html>'
            )

        @app.route('/video_feed')
        def video_feed():
            return Response(
                self._mjpeg_generator(),
                mimetype='multipart/x-mixed-replace; boundary=frame',
            )

        # use_reloader=False and threaded=True are important: this runs
        # inside a background thread, not Flask's own main thread.
        app.run(host=self.http_host, port=self.http_port, threaded=True, use_reloader=False)


def main(args=None):
    rclpy.init(args=args)
    node = VideoStreamServerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
