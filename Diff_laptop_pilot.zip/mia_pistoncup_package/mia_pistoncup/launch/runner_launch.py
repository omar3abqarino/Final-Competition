"""runner_launch.py

Launches every node that runs on the RUNNER's laptop:
    - ultrasonic_safety_node    (single gateway: /cmd_vel_requested -> /cmd_vel)
    - detection_node            (YOLO scroll detection)
    - search_controller_node    (autonomous rotate-sweep search)
    - state_machine_node        (Runner console + /robot_state)
    - teleop_bridge_node        (receives Pilot's commands over TCP)
    - video_stream_server_node  (serves the mono camera feed to the Pilot)

Nothing except ultrasonic_safety_node ever publishes to /cmd_vel -- every
other node above requests motion on /cmd_vel_requested instead.

It assumes the low-level robot driver (motor controller subscribing
/cmd_vel, ultrasonic publisher, and the /mono/image camera driver) is
already running separately, since that part was provided ready-made.

Usage:
    ros2 launch mia_pistoncup runner_launch.py

Override any parameter from the command line, e.g.:
    ros2 launch mia_pistoncup runner_launch.py model_path:=/home/team/best.pt
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_share = get_package_share_directory('mia_pistoncup')
    default_params_file = os.path.join(pkg_share, 'config', 'params.yaml')

    params_file_arg = DeclareLaunchArgument(
        'params_file',
        default_value=default_params_file,
        description='Path to the YAML file with node parameters.',
    )
    model_path_arg = DeclareLaunchArgument(
        'model_path',
        default_value='models/best.pt',
        description='Path to the trained YOLO weights file.',
    )

    params_file = LaunchConfiguration('params_file')

    ultrasonic_safety = Node(
        package='mia_pistoncup',
        executable='ultrasonic_safety_node',
        name='ultrasonic_safety_node',
        output='screen',
        parameters=[params_file],
    )
    detection = Node(
        package='mia_pistoncup',
        executable='detection_node',
        name='detection_node',
        output='screen',
        parameters=[params_file, {'model_path': LaunchConfiguration('model_path')}],
    )
    search = Node(
        package='mia_pistoncup',
        executable='search_controller_node',
        name='search_controller_node',
        output='screen',
        parameters=[params_file],
    )
    state_machine = Node(
        package='mia_pistoncup',
        executable='state_machine_node',
        name='state_machine_node',
        output='screen',
        parameters=[params_file],
        # emulate_tty lets the interactive input() console work nicely.
        emulate_tty=True,
    )
    teleop_bridge = Node(
        package='mia_pistoncup',
        executable='teleop_bridge_node',
        name='teleop_bridge_node',
        output='screen',
        parameters=[params_file],
    )
    video_stream = Node(
        package='mia_pistoncup',
        executable='video_stream_server_node',
        name='video_stream_server_node',
        output='screen',
        parameters=[params_file],
    )

    return LaunchDescription([
        params_file_arg,
        model_path_arg,
        ultrasonic_safety,
        detection,
        search,
        state_machine,
        teleop_bridge,
        video_stream,
    ])
