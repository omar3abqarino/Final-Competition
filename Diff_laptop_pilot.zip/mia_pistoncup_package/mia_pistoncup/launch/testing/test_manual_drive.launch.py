"""test_manual_drive.launch.py  (TESTING - not the competition launch)

Step 2/3 of hardware bring-up: drive the robot from the Pilot station and
view the camera feed, WITHOUT the detection or state-machine nodes
running. Useful for confirming the drivetrain, TCP link, and video stream
all work before trusting the full competition stack.

Note: /robot_state is never published by anything in this launch file, so
teleop_bridge_node will sit idle (it only requests motion while state ==
TELEOP). For a pure drivetrain test, temporarily run:
    ros2 topic pub /robot_state std_msgs/String "{data: 'TELEOP'}" --once
in another terminal after this launch is up.

Usage:
    ros2 launch mia_pistoncup test_manual_drive.launch.py
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_share = get_package_share_directory('mia_pistoncup')
    default_params_file = os.path.join(pkg_share, 'config', 'params.yaml')

    params_file_arg = DeclareLaunchArgument(
        'params_file',
        default_value=default_params_file,
        description='Path to the YAML file with node parameters.',
    )
    params_file = LaunchConfiguration('params_file')

    ultrasonic_safety = Node(
        package='mia_pistoncup',
        executable='ultrasonic_safety_node',
        name='ultrasonic_safety_node',
        output='screen',
        parameters=[params_file],
    )
    teleop_bridge = Node(
        package='mia_pistoncup',
        executable='teleop_bridge_node',
        name='teleop_bridge_node',
        output='screen',
        parameters=[params_file],
    )
    video_stream = Node(
        package='mia_pistoncup',
        executable='video_stream_server_node',
        name='video_stream_server_node',
        output='screen',
        parameters=[params_file],
    )

    return LaunchDescription([
        params_file_arg,
        ultrasonic_safety,
        teleop_bridge,
        video_stream,
    ])
