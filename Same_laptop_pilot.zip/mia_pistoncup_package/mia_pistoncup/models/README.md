# Model weights go here

Drop your trained YOLOv8 or YOLOv11 weights file here as:

    models/best.pt

That's the default `model_path` parameter in `config/params.yaml`. You can
also point at a different location entirely by overriding the parameter at
launch time:

    ros2 launch mia_pistoncup runner_launch.py model_path:=/home/team/runs/detect/train/weights/best.pt

## Expected model format
- 2 classes, indices 0 and 1 (matching `class_a_name` / `class_b_name` in
  `config/params.yaml` -- rename those once you've settled the
  dataset/class question from the earlier discussion).
- Trained with the `ultralytics` package (works for both YOLOv8 and
  YOLOv11 -- same `YOLO(...)` loading API either way, no code changes
  needed in `detection_node.py`).
