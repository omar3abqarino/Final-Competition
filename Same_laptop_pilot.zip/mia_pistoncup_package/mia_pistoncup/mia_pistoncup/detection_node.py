#!/usr/bin/env python3
"""detection_node.py

Runs a YOLO model (YOLOv8 or YOLOv11, both use the same `ultralytics` API)
on the mono camera feed to autonomously find the two scroll classes.

Only does work while /robot_state == SEARCHING, to save CPU/GPU and to make
sure a stray detection before the round even starts can never "confirm" a
result.

Publishes /detection_status (std_msgs/String, JSON-encoded) every frame:

    {
      "class_a_seen": true/false,   # seen in the CURRENT frame
      "class_b_seen": true/false,
      "class_a_streak": 7,          # consecutive frames class A was seen
      "class_b_streak": 12,
      "required_streak": 10,
      "confirmed": false            # true once BOTH streaks reach the
                                     # required consecutive-frame count
    }

state_machine_node listens to this topic and moves SEARCHING ->
AWAITING_GREEN_CARD the instant "confirmed" becomes true.

NOTE ON CLASSES:
  This assumes the trained model has exactly 2 classes. Rename
  `class_a_name` / `class_b_name` (and the underlying dataset labels) once
  your dataset/labeling question is resolved -- the class *names* here are
  only used for logging; matching is done by class index (0 and 1).
"""
import json
import threading

import cv2
import rclpy
from cv_bridge import CvBridge
from rclpy.node import Node
from rclpy.qos import QoSDurabilityPolicy, QoSHistoryPolicy, QoSProfile
from sensor_msgs.msg import Image
from std_msgs.msg import String

from mia_pistoncup import robot_state


class DetectionNode(Node):

    def __init__(self):
        super().__init__('detection_node')

        # ---- Parameters (override via launch file / config/params.yaml) ----
        self.declare_parameter('model_path', 'models/best.pt')
        self.declare_parameter('camera_topic', '/mono/image')
        self.declare_parameter('confidence_threshold', 0.6)
        self.declare_parameter('required_consecutive_frames', 10)
        self.declare_parameter('class_a_name', 'scroll_a')
        self.declare_parameter('class_b_name', 'scroll_b')
        self.declare_parameter('show_debug_window', False)

        self.model_path = self.get_parameter('model_path').value
        self.camera_topic = self.get_parameter('camera_topic').value
        self.conf_threshold = float(self.get_parameter('confidence_threshold').value)
        self.required_streak = int(self.get_parameter('required_consecutive_frames').value)
        self.class_a_name = self.get_parameter('class_a_name').value
        self.class_b_name = self.get_parameter('class_b_name').value
        self.show_debug_window = bool(self.get_parameter('show_debug_window').value)

        # ---- YOLO model ----
        # Imported lazily so the rest of the package still works even if
        # `ultralytics` isn't installed yet on a machine that only needs to
        # run e.g. the pilot script.
        try:
            from ultralytics import YOLO
            self.model = YOLO(self.model_path)
            self.get_logger().info(f'Loaded YOLO model from: {self.model_path}')
        except Exception as exc:  # noqa: BLE001 - we want to keep running & log clearly
            self.model = None
            self.get_logger().error(
                f'Could not load YOLO model from "{self.model_path}": {exc}\n'
                'Drop a trained best.pt into the models/ folder (or update the '
                '"model_path" parameter). Detection will stay idle until then.'
            )

        self.bridge = CvBridge()

        # ---- State tracking ----
        self.current_state = robot_state.IDLE
        self.class_a_streak = 0
        self.class_b_streak = 0
        self._lock = threading.Lock()

        # /robot_state uses TRANSIENT_LOCAL so late-joining nodes still get
        # the current value immediately instead of waiting for the next change.
        latched_qos = QoSProfile(
            depth=1,
            durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
            history=QoSHistoryPolicy.KEEP_LAST,
        )

        self.state_sub = self.create_subscription(
            String, '/robot_state', self.state_callback, latched_qos)
        self.image_sub = self.create_subscription(
            Image, self.camera_topic, self.image_callback, 10)
        self.status_pub = self.create_publisher(String, '/detection_status', 10)

        self.get_logger().info('detection_node ready. Waiting for SEARCHING state...')

    def state_callback(self, msg: String):
        with self._lock:
            new_state = msg.data
            if new_state != self.current_state and new_state == robot_state.SEARCHING:
                # Fresh round: reset streak counters.
                self.class_a_streak = 0
                self.class_b_streak = 0
                self.get_logger().info('State -> SEARCHING: detection counters reset.')
            self.current_state = new_state

    def image_callback(self, msg: Image):
        with self._lock:
            active = (self.current_state == robot_state.SEARCHING)

        if not active or self.model is None:
            return

        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')

        # verbose=False keeps the terminal clean during the match.
        results = self.model.predict(frame, conf=self.conf_threshold, verbose=False)

        class_a_seen_this_frame = False
        class_b_seen_this_frame = False

        if results:
            boxes = results[0].boxes
            for box in boxes:
                cls_id = int(box.cls[0])
                if cls_id == 0:
                    class_a_seen_this_frame = True
                elif cls_id == 1:
                    class_b_seen_this_frame = True

        with self._lock:
            self.class_a_streak = self.class_a_streak + 1 if class_a_seen_this_frame else 0
            self.class_b_streak = self.class_b_streak + 1 if class_b_seen_this_frame else 0
            confirmed = (self.class_a_streak >= self.required_streak and
                         self.class_b_streak >= self.required_streak)

            status = {
                'class_a_seen': class_a_seen_this_frame,
                'class_b_seen': class_b_seen_this_frame,
                'class_a_streak': self.class_a_streak,
                'class_b_streak': self.class_b_streak,
                'required_streak': self.required_streak,
                'confirmed': confirmed,
            }

        self.status_pub.publish(String(data=json.dumps(status)))

        if confirmed:
            self.get_logger().info(
                f'CONFIRMED: both {self.class_a_name} and {self.class_b_name} '
                f'seen for {self.required_streak}+ consecutive frames.'
            )

        if self.show_debug_window:
            annotated = results[0].plot() if results else frame
            cv2.imshow('detection_node debug', annotated)
            cv2.waitKey(1)


def main(args=None):
    rclpy.init(args=args)
    node = DetectionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
