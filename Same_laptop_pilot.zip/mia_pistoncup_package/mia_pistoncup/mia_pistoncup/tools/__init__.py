"""Calibration/diagnostic tools for hardware bring-up.

Nothing in this subpackage is used during an actual competition round --
see the top-level README's "Competition code vs. testing tools" section.
Everything here is safe to run standalone against the real robot for
checking wiring and tuning timing constants before you trust the
competition stack with them.
"""
