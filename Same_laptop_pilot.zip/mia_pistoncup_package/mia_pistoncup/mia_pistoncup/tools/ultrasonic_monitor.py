#!/usr/bin/env python3
"""ultrasonic_monitor.py  (TESTING TOOL - not used during a competition round)

Read-only. Subscribes to /ultrasonic_distance and prints readings to the
terminal. Never publishes anything, so it's always safe to run alongside
anything else -- use it first, before any motion test, to confirm the
sensor is actually wired up and publishing sane numbers.

Usage:
    ros2 run mia_pistoncup ultrasonic_monitor

Or skip this tool entirely and just echo the raw topic:
    ros2 topic echo /ultrasonic_distance
"""
import math
import time

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32


class UltrasonicMonitor(Node):

    def __init__(self):
        super().__init__('ultrasonic_monitor')

        self.declare_parameter('ultrasonic_topic', '/ultrasonic_distance')
        self.declare_parameter('print_period_s', 0.2)
        self.declare_parameter('stale_timeout_s', 0.75)

        self.ultrasonic_topic = self.get_parameter('ultrasonic_topic').value
        self.print_period = float(self.get_parameter('print_period_s').value)
        self.stale_timeout = float(self.get_parameter('stale_timeout_s').value)

        self.distance = math.inf
        self.last_sensor_time = 0.0
        self.sample_count = 0

        self.create_subscription(Float32, self.ultrasonic_topic, self.distance_callback, 10)
        self.timer = self.create_timer(self.print_period, self.print_tick)

        self.get_logger().info(f'Monitoring {self.ultrasonic_topic} (read-only, no motion)...')

    def distance_callback(self, msg: Float32):
        self.distance = float(msg.data)
        self.last_sensor_time = time.monotonic()
        self.sample_count += 1

    def print_tick(self):
        age = time.monotonic() - self.last_sensor_time if self.sample_count else math.inf
        if self.sample_count == 0:
            self.get_logger().warn(f'No messages received yet on {self.ultrasonic_topic}.')
        elif age > self.stale_timeout:
            self.get_logger().warn(
                f'STALE ({age:.2f}s since last reading) - last value: {self.distance:.3f} m'
            )
        else:
            self.get_logger().info(f'distance = {self.distance:.3f} m  (samples: {self.sample_count})')


def main(args=None):
    rclpy.init(args=args)
    node = UltrasonicMonitor()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
