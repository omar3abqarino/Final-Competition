#!/usr/bin/env python3
"""motion_test.py  (TESTING TOOL - not used during a competition round)

Publishes a single calibrated, timed Twist command on /cmd_vel_requested
(always run ultrasonic_safety_node alongside this, so it's still gated).

There's no odometry on this robot, so search_controller_node's rotate/
forward timing constants (step_rotate_duration, angular_speed,
forward_duration, linear_speed in config/params.yaml) are just "apply
this speed for this many seconds" guesses. This tool measures the real,
physical result of one such command so you can calibrate those constants
against the actual robot instead of guessing blind.

Always start with small magnitudes in a clear area.

Usage examples:
    ros2 run mia_pistoncup motion_test --ros-args \\
        -p mode:=forward -p magnitude:=0.20 -p linear_speed_mps:=0.15 -p auto_start:=true

    ros2 run mia_pistoncup motion_test --ros-args \\
        -p mode:=rotate_left -p magnitude:=30.0 -p angular_speed_radps:=0.5 -p auto_start:=true

`magnitude` is meters for forward/backward, degrees for rotate_left/rotate_right.
Measure the ACTUAL distance/angle the robot moved with a tape measure or
protractor and compare it to `magnitude` to see how well-calibrated your
speed parameters are.
"""
import math
import time

import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node


class MotionTest(Node):

    def __init__(self):
        super().__init__('motion_test')

        self.declare_parameter('cmd_vel_topic', '/cmd_vel_requested')
        self.declare_parameter('mode', 'forward')  # forward / backward / rotate_left / rotate_right
        self.declare_parameter('magnitude', 0.25)  # meters for linear, degrees for rotate
        self.declare_parameter('linear_speed_mps', 0.15)
        self.declare_parameter('angular_speed_radps', 0.5)
        self.declare_parameter('startup_delay_s', 2.0)
        self.declare_parameter('auto_start', False)

        self.cmd_vel_topic = self.get_parameter('cmd_vel_topic').value
        self.mode = str(self.get_parameter('mode').value).lower().strip()
        self.magnitude = abs(float(self.get_parameter('magnitude').value))
        self.linear_speed = abs(float(self.get_parameter('linear_speed_mps').value))
        self.angular_speed = abs(float(self.get_parameter('angular_speed_radps').value))
        self.startup_delay = max(0.0, float(self.get_parameter('startup_delay_s').value))
        self.auto_start = bool(self.get_parameter('auto_start').value)

        if self.mode not in ('forward', 'backward', 'rotate_left', 'rotate_right'):
            raise ValueError('mode must be one of: forward, backward, rotate_left, rotate_right')

        if self.mode in ('forward', 'backward'):
            if self.linear_speed <= 0.0:
                raise ValueError('linear_speed_mps must be > 0')
            self.duration = self.magnitude / self.linear_speed
        else:
            if self.angular_speed <= 0.0:
                raise ValueError('angular_speed_radps must be > 0')
            self.duration = math.radians(self.magnitude) / self.angular_speed

        self.cmd_pub = self.create_publisher(Twist, self.cmd_vel_topic, 10)
        self.node_started_at = time.monotonic()
        self.motion_started_at = None
        self.done = False

        self.timer = self.create_timer(0.05, self._tick)

        self.get_logger().info(
            f'motion_test configured: mode={self.mode}, magnitude={self.magnitude}, '
            f'expected duration={self.duration:.2f}s, publishing to {self.cmd_vel_topic}'
        )
        if not self.auto_start:
            self.get_logger().info(
                'Waiting - re-run with -p auto_start:=true once the area is clear '
                'and ultrasonic_safety_node is running in another terminal.'
            )

    def _tick(self):
        if self.done:
            return
        if not self.auto_start:
            self._publish_stop()
            return

        elapsed_since_node_start = time.monotonic() - self.node_started_at
        if elapsed_since_node_start < self.startup_delay:
            self._publish_stop()
            return

        if self.motion_started_at is None:
            self.motion_started_at = time.monotonic()
            self.get_logger().warn('Starting motion test NOW.')

        motion_elapsed = time.monotonic() - self.motion_started_at
        if motion_elapsed < self.duration:
            msg = Twist()
            if self.mode == 'forward':
                msg.linear.x = self.linear_speed
            elif self.mode == 'backward':
                msg.linear.x = -self.linear_speed
            elif self.mode == 'rotate_left':
                msg.angular.z = self.angular_speed
            elif self.mode == 'rotate_right':
                msg.angular.z = -self.angular_speed
            self.cmd_pub.publish(msg)
            return

        self._publish_stop()
        self.done = True
        self.get_logger().info(
            'Motion test complete. Robot commanded to STOP. '
            'Measure how far/how much it actually moved and compare to the requested magnitude.'
        )

    def _publish_stop(self):
        self.cmd_pub.publish(Twist())


def main(args=None):
    rclpy.init(args=args)
    node = MotionTest()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node._publish_stop()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
