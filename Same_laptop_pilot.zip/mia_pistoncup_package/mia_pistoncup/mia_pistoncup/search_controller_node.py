#!/usr/bin/env python3
"""search_controller_node.py

Autonomous search motion for the SEARCHING phase, following the pattern
the team chose:

    1. Rotate in place, step by step, sweeping across an arc.
    2. If both scrolls aren't confirmed by the end of the sweep, rotate
       back the same number of steps (same speed, opposite direction) to
       return to roughly the original heading.
    3. Creep forward a short distance.
    4. Repeat from step 1.

This is fully open-loop / time-based (no odometry needed): each "step" is
just "apply this Twist for this many seconds". It won't be perfectly
precise, but it doesn't need to be -- detection_node keeps looking every
frame regardless of exactly where the robot is pointed, and the sweep
repeats automatically until something is found.

Only requests motion (on /cmd_vel_requested) while /robot_state ==
SEARCHING. This node does NOT write to /cmd_vel directly -- ultrasonic_safety_node
is the single gateway that turns requested motion into the real /cmd_vel,
so the robot is protected even if this node's own logic misses something.
The ultrasonic reading is still read here too, but only to decide whether
it's worth *attempting* the forward creep step at all (a planning
decision, separate from the safety gateway's job of clamping/stopping
whatever gets requested).

ASSUMED MESSAGE TYPE for /ultrasonic_distance: std_msgs/Float32 (a single
distance reading in meters). If the provided low-level driver actually
publishes sensor_msgs/Range instead, change the import/subscription below
and read `msg.range` instead of `msg.data` -- everything else stays the same.
"""
import json
from collections import deque

import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node
from rclpy.qos import QoSDurabilityPolicy, QoSHistoryPolicy, QoSProfile
from std_msgs.msg import Float32, String

from mia_pistoncup import robot_state


class SearchControllerNode(Node):

    def __init__(self):
        super().__init__('search_controller_node')

        # ---- Parameters ----
        self.declare_parameter('cmd_vel_topic', '/cmd_vel_requested')  # NOT /cmd_vel directly - see module docstring
        self.declare_parameter('angular_speed', 0.5)       # rad/s while rotating
        self.declare_parameter('linear_speed', 0.15)        # m/s while creeping forward
        self.declare_parameter('step_rotate_duration', 0.35)  # sec of rotation per step
        self.declare_parameter('step_pause_duration', 0.4)    # sec paused so the camera/detector can catch up
        self.declare_parameter('num_steps_out', 6)           # steps in one direction = the sweep arc
        self.declare_parameter('forward_duration', 0.6)      # sec of forward creep between sweeps
        self.declare_parameter('min_wall_distance', 0.25)    # meters - abort forward creep if closer than this
        self.declare_parameter('max_forward_moves', 6)       # safety cap before warning the Runner

        self.cmd_vel_topic = self.get_parameter('cmd_vel_topic').value
        self.angular_speed = float(self.get_parameter('angular_speed').value)
        self.linear_speed = float(self.get_parameter('linear_speed').value)
        self.step_rotate_duration = float(self.get_parameter('step_rotate_duration').value)
        self.step_pause_duration = float(self.get_parameter('step_pause_duration').value)
        self.num_steps_out = int(self.get_parameter('num_steps_out').value)
        self.forward_duration = float(self.get_parameter('forward_duration').value)
        self.min_wall_distance = float(self.get_parameter('min_wall_distance').value)
        self.max_forward_moves = int(self.get_parameter('max_forward_moves').value)

        latched_qos = QoSProfile(
            depth=1,
            durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
            history=QoSHistoryPolicy.KEEP_LAST,
        )

        self.cmd_pub = self.create_publisher(Twist, self.cmd_vel_topic, 10)
        self.state_sub = self.create_subscription(
            String, '/robot_state', self.state_callback, latched_qos)
        self.detection_sub = self.create_subscription(
            String, '/detection_status', self.detection_callback, 10)
        self.ultrasonic_sub = self.create_subscription(
            Float32, '/ultrasonic_distance', self.ultrasonic_callback, 10)

        self.current_state = robot_state.IDLE
        self.confirmed = False
        self.last_distance = None  # meters
        self.forward_move_count = 0

        self.action_queue = deque()
        self.current_action = None       # ('rotate', +1/-1) or ('pause',) or ('forward',)
        self.action_elapsed = 0.0

        self.control_period = 0.05  # 20 Hz
        self.timer = self.create_timer(self.control_period, self.control_loop)

        self.get_logger().info('search_controller_node ready. Waiting for SEARCHING state...')

    # ---- Subscriptions ----
    def state_callback(self, msg: String):
        new_state = msg.data
        if new_state == robot_state.SEARCHING and self.current_state != robot_state.SEARCHING:
            self.get_logger().info('State -> SEARCHING: starting rotate-sweep search.')
            self.confirmed = False
            self.forward_move_count = 0
            self._rebuild_action_queue()
        if new_state != robot_state.SEARCHING:
            self._stop_robot()
            self.action_queue.clear()
            self.current_action = None
        self.current_state = new_state

    def detection_callback(self, msg: String):
        try:
            status = json.loads(msg.data)
        except (json.JSONDecodeError, TypeError):
            return
        self.confirmed = bool(status.get('confirmed', False))
        if self.confirmed:
            self._stop_robot()
            self.action_queue.clear()
            self.current_action = None

    def ultrasonic_callback(self, msg: Float32):
        self.last_distance = float(msg.data)

    # ---- Search pattern ----
    def _rebuild_action_queue(self):
        """Build one full cycle: sweep out, sweep back, creep forward."""
        self.action_queue.clear()
        for _ in range(self.num_steps_out):
            self.action_queue.append(('rotate', +1))
            self.action_queue.append(('pause',))
        for _ in range(self.num_steps_out):
            self.action_queue.append(('rotate', -1))
            self.action_queue.append(('pause',))
        self.action_queue.append(('forward',))
        self.action_queue.append(('pause',))

    def _duration_for(self, action):
        kind = action[0]
        if kind == 'rotate':
            return self.step_rotate_duration
        if kind == 'pause':
            return self.step_pause_duration
        if kind == 'forward':
            return self.forward_duration
        return 0.0

    def control_loop(self):
        if self.current_state != robot_state.SEARCHING or self.confirmed:
            return

        if self.current_action is None:
            if not self.action_queue:
                # Completed a full cycle without confirmation -> loop again.
                if self.forward_move_count >= self.max_forward_moves:
                    self.get_logger().warn(
                        f'Reached max_forward_moves ({self.max_forward_moves}) without '
                        'confirming both scrolls. Ask a judge for a reset / reposition '
                        'if the robot looks stuck.'
                    )
                    self.forward_move_count = 0
                self._rebuild_action_queue()
            self.current_action = self.action_queue.popleft()
            self.action_elapsed = 0.0

            # Safety check right when a forward creep is about to start.
            if self.current_action[0] == 'forward':
                if self.last_distance is not None and self.last_distance < self.min_wall_distance:
                    self.get_logger().warn(
                        f'Too close to a wall/scroll ({self.last_distance:.2f} m) - '
                        'skipping forward creep this cycle.'
                    )
                    self.current_action = ('pause',)
                else:
                    self.forward_move_count += 1

        self._publish_for_action(self.current_action)

        self.action_elapsed += self.control_period
        if self.action_elapsed >= self._duration_for(self.current_action):
            self.current_action = None  # move to next action next tick

    def _publish_for_action(self, action):
        twist = Twist()
        kind = action[0]
        if kind == 'rotate':
            direction = action[1]
            twist.angular.z = self.angular_speed * direction
        elif kind == 'forward':
            twist.linear.x = self.linear_speed
        # 'pause' -> all zeros
        self.cmd_pub.publish(twist)

    def _stop_robot(self):
        self.cmd_pub.publish(Twist())


def main(args=None):
    rclpy.init(args=args)
    node = SearchControllerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node._stop_robot()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
