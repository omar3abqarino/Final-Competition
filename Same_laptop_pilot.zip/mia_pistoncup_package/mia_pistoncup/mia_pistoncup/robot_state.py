"""Shared state names used across all nodes.

We use plain strings published on the /robot_state topic (std_msgs/String)
instead of a custom ROS2 message/interface package. That keeps the whole
project buildable with plain `ament_python` and no extra `_interfaces`
package to generate and rebuild -- one less moving part on competition day.

State flow for one round:

    IDLE
      | Runner types "start"
      v
    SEARCHING                  (autonomous scroll detection + search motion)
      | detection_node confirms both scrolls for N consecutive frames
      v
    AWAITING_GREEN_CARD        (robot holds still, Runner shows judge the screen)
      | Runner types "green" once the judge raises the green card
      v
    TELEOP                     (Pilot drives manually with keyboard, pushes
                                 the 3rd scroll, returns to start zone)
      | Runner types "reset" (new round / next match)
      v
    IDLE
"""

IDLE = "IDLE"
SEARCHING = "SEARCHING"
AWAITING_GREEN_CARD = "AWAITING_GREEN_CARD"
TELEOP = "TELEOP"

ALL_STATES = (IDLE, SEARCHING, AWAITING_GREEN_CARD, TELEOP)
