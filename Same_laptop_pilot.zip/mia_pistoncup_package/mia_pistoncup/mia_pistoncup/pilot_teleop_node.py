#!/usr/bin/env python3
"""pilot_teleop_node.py

The Pilot now sits at the SAME laptop as the Runner (previously a
separate machine linked over TCP + an MJPEG stream). This node replaces
both teleop_bridge_node.py and video_stream_server_node.py with one local
node: it shows the mono camera feed in a window and reads the Pilot's
keyboard directly from that window, using OpenCV's own key capture
(cv2.waitKey) -- no network, no separate laptop, no video streaming.

Controls (differential drive), captured while the camera window has
focus:
    W  - drive forward
    S  - drive backward
    A  - turn left (counter-clockwise)
    D  - turn right (clockwise)
    (any other key, or no key) -> stop

Like every other motion source in this package, this node does NOT write
to /cmd_vel directly -- it publishes requested motion on
/cmd_vel_requested, and ultrasonic_safety_node is the single gateway that
turns that into the real /cmd_vel.

Only requests non-zero motion while /robot_state == TELEOP, so the Pilot
physically cannot move the robot during the autonomous phase -- the
camera window is still shown in every state so the Runner/Pilot can watch
the feed throughout, it just ignores drive keys outside of TELEOP.
"""
import cv2
import rclpy
from cv_bridge import CvBridge, CvBridgeError
from geometry_msgs.msg import Twist
from rclpy.node import Node
from rclpy.qos import QoSDurabilityPolicy, QoSHistoryPolicy, QoSProfile
from sensor_msgs.msg import Image
from std_msgs.msg import String

from mia_pistoncup import robot_state


class PilotTeleopNode(Node):

    def __init__(self):
        super().__init__('pilot_teleop_node')

        self.declare_parameter('camera_topic', '/mono/image')
        self.declare_parameter('cmd_vel_topic', '/cmd_vel_requested')
        self.declare_parameter('linear_speed', 0.3)
        self.declare_parameter('angular_speed', 0.6)
        self.declare_parameter('window_name', 'MIA Piston Cup - Pilot View (mono cam)')

        self.camera_topic = self.get_parameter('camera_topic').value
        self.cmd_vel_topic = self.get_parameter('cmd_vel_topic').value
        self.linear_speed = float(self.get_parameter('linear_speed').value)
        self.angular_speed = float(self.get_parameter('angular_speed').value)
        self.window_name = self.get_parameter('window_name').value

        self.bridge = CvBridge()
        self.current_state = robot_state.IDLE

        latched_qos = QoSProfile(
            depth=1,
            durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
            history=QoSHistoryPolicy.KEEP_LAST,
        )

        self.cmd_pub = self.create_publisher(Twist, self.cmd_vel_topic, 10)
        self.state_sub = self.create_subscription(
            String, '/robot_state', self.state_callback, latched_qos)
        self.image_sub = self.create_subscription(
            Image, self.camera_topic, self.image_callback, 10)

        cv2.namedWindow(self.window_name, cv2.WINDOW_NORMAL)

        self.get_logger().info(
            'pilot_teleop_node ready. Click the camera window to focus it, then '
            'W/S forward-back, A/D turn left-right (active only during TELEOP).'
        )

    def state_callback(self, msg: String):
        self.current_state = msg.data

    def image_callback(self, msg: Image):
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except CvBridgeError as exc:
            self.get_logger().error(f'cv_bridge error: {exc}')
            return

        cv2.putText(frame, f'State: {self.current_state}', (10, 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
        cv2.imshow(self.window_name, frame)
        key = cv2.waitKey(1) & 0xFF

        twist = Twist()
        if self.current_state == robot_state.TELEOP:
            if key in (ord('w'), ord('W')):
                twist.linear.x = self.linear_speed
            elif key in (ord('s'), ord('S')):
                twist.linear.x = -self.linear_speed
            elif key in (ord('a'), ord('A')):
                twist.angular.z = self.angular_speed
            elif key in (ord('d'), ord('D')):
                twist.angular.z = -self.angular_speed
            # any other key (or none) -> stays all zero

        self.cmd_pub.publish(twist)

    def destroy_node(self) -> bool:
        try:
            cv2.destroyAllWindows()
        except Exception:
            pass
        return super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = PilotTeleopNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.cmd_pub.publish(Twist())
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
