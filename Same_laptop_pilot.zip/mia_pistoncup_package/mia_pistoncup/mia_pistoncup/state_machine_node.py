#!/usr/bin/env python3
"""state_machine_node.py

The single source of truth for /robot_state. Runs on the Runner's laptop.

The Runner controls it by typing short commands + Enter in the terminal
this node is running in:

    start   - IDLE          -> SEARCHING           (begin autonomous phase)
    green   - AWAITING_GREEN_CARD -> TELEOP         (judge raised the green card)
    reset   - any state     -> IDLE                 (emergency stop / new round)
    status  - just prints the current state
    quit    - shuts this node down

The transition SEARCHING -> AWAITING_GREEN_CARD happens automatically the
instant detection_node reports "confirmed": true on /detection_status --
no need for the Runner to do anything for that step, just watch the
terminal for the "show the judge" message.

/robot_state is published with TRANSIENT_LOCAL QoS (depth 1) so that any
node started late (or restarted) immediately receives the current state
instead of silently staying IDLE.
"""
import json
import threading

import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node
from rclpy.qos import QoSDurabilityPolicy, QoSHistoryPolicy, QoSProfile
from std_msgs.msg import String

from mia_pistoncup import robot_state


class StateMachineNode(Node):

    def __init__(self):
        super().__init__('state_machine_node')

        # NOT /cmd_vel directly - this node's emergency stop also goes through
        # ultrasonic_safety_node like every other command source, so that node
        # remains the single, only writer of the real /cmd_vel topic.
        self.declare_parameter('cmd_vel_topic', '/cmd_vel_requested')
        self.cmd_vel_topic = self.get_parameter('cmd_vel_topic').value

        latched_qos = QoSProfile(
            depth=1,
            durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
            history=QoSHistoryPolicy.KEEP_LAST,
        )

        self.state_pub = self.create_publisher(String, '/robot_state', latched_qos)
        self.cmd_pub = self.create_publisher(Twist, self.cmd_vel_topic, 10)
        self.detection_sub = self.create_subscription(
            String, '/detection_status', self.detection_callback, 10)

        self.state = robot_state.IDLE
        self._publish_state()

        self._print_menu()

        # Read Runner commands from stdin in a background thread so it
        # doesn't block ROS2 spinning. Using input() (needs Enter) instead
        # of raw single-key capture keeps this simple and terminal-portable.
        self._input_thread = threading.Thread(target=self._input_loop, daemon=True)
        self._input_thread.start()

    def _print_menu(self):
        self.get_logger().info(
            '\n'
            '=== MIA Piston Cup - Runner Console ===\n'
            "  start  -> begin autonomous SEARCHING phase\n"
            "  green  -> confirm judge's green card, switch to Pilot TELEOP\n"
            "  reset  -> emergency stop / reset to IDLE for next round\n"
            "  status -> print current state\n"
            "  quit   -> shut down this node\n"
            '========================================'
        )

    def _set_state(self, new_state):
        if new_state == self.state:
            return
        self.get_logger().info(f'State: {self.state} -> {new_state}')
        self.state = new_state
        self._publish_state()

    def _publish_state(self):
        self.state_pub.publish(String(data=self.state))

    def detection_callback(self, msg: String):
        if self.state != robot_state.SEARCHING:
            return
        try:
            status = json.loads(msg.data)
        except (json.JSONDecodeError, TypeError):
            return
        if status.get('confirmed', False):
            self._set_state(robot_state.AWAITING_GREEN_CARD)
            self.get_logger().info(
                '>>> BOTH SCROLLS CONFIRMED. Robot is holding still. <<<\n'
                ">>> Show this to the judge, then type 'green' once you get the green card. <<<"
            )

    def _input_loop(self):
        while rclpy.ok():
            try:
                cmd = input().strip().lower()
            except EOFError:
                break

            if cmd == 'start':
                if self.state == robot_state.IDLE:
                    self._set_state(robot_state.SEARCHING)
                else:
                    self.get_logger().warn(f"Can't 'start' from state {self.state} (must be IDLE).")

            elif cmd == 'green':
                if self.state == robot_state.AWAITING_GREEN_CARD:
                    self._set_state(robot_state.TELEOP)
                    self.get_logger().info('>>> TELEOP enabled. Pilot has control. <<<')
                else:
                    self.get_logger().warn(
                        f"Can't 'green' from state {self.state} "
                        '(must be AWAITING_GREEN_CARD).'
                    )

            elif cmd == 'reset':
                self.cmd_pub.publish(Twist())  # immediate safety stop
                self._set_state(robot_state.IDLE)
                self.get_logger().info('Reset to IDLE. Ready for the next round.')

            elif cmd == 'status':
                self.get_logger().info(f'Current state: {self.state}')

            elif cmd == 'quit':
                self.get_logger().info('Shutting down state_machine_node...')
                rclpy.shutdown()
                break

            elif cmd == '':
                continue

            else:
                self.get_logger().warn(f'Unknown command: "{cmd}". Try: start / green / reset / status / quit')


def main(args=None):
    rclpy.init(args=args)
    node = StateMachineNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            node.cmd_pub.publish(Twist())
        except Exception:
            pass
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
