#!/usr/bin/env python3
"""ultrasonic_safety_node.py

The single safety gateway between every command source and the real
robot. This is competition-critical code (not a test tool) -- it runs
every round.

Every other node that wants to move the robot (search_controller_node,
pilot_teleop_node, state_machine_node's emergency stop, and the
tools/motion_test.py calibration tool) publishes its REQUESTED motion on

    /cmd_vel_requested

instead of /cmd_vel directly. This node is the only thing that publishes
to the real

    /cmd_vel

It reads /ultrasonic_distance and, right before forwarding a requested
command, clamps or zeroes the forward speed if something is too close (or
if the sensor has gone stale/silent). Reversing away from an obstacle and
pure rotation are still allowed by default, since those don't drive the
robot into whatever tripped the sensor.

Why a single gateway instead of each controller checking the sensor
itself? Every command source stays simple (it just asks for what it
wants), and there's exactly one place to look if something ever drives
into a wall -- one node, one set of safety parameters, no chance of a
future controller forgetting to add its own check.

ASSUMED MESSAGE TYPE for /ultrasonic_distance: std_msgs/Float32 (a single
distance reading in meters), matching every other node in this package.
If the provided low-level driver actually publishes sensor_msgs/Range
instead, change the import/subscription below and read `msg.range`
instead of `msg.data` -- nothing else needs to change.
"""
import math
import time

import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node
from std_msgs.msg import Float32


class UltrasonicSafetyNode(Node):

    def __init__(self):
        super().__init__('ultrasonic_safety_node')

        self.declare_parameter('ultrasonic_topic', '/ultrasonic_distance')
        self.declare_parameter('input_cmd_topic', '/cmd_vel_requested')
        self.declare_parameter('output_cmd_topic', '/cmd_vel')
        self.declare_parameter('stop_distance_m', 0.20)
        self.declare_parameter('slow_distance_m', 0.35)
        self.declare_parameter('slow_factor', 0.35)
        self.declare_parameter('stale_timeout_s', 0.5)
        self.declare_parameter('allow_rotation_when_blocked', True)

        self.ultrasonic_topic = self.get_parameter('ultrasonic_topic').value
        self.input_cmd_topic = self.get_parameter('input_cmd_topic').value
        self.output_cmd_topic = self.get_parameter('output_cmd_topic').value
        self.stop_distance = float(self.get_parameter('stop_distance_m').value)
        self.slow_distance = float(self.get_parameter('slow_distance_m').value)
        self.slow_factor = float(self.get_parameter('slow_factor').value)
        self.stale_timeout = float(self.get_parameter('stale_timeout_s').value)
        self.allow_rotation = bool(self.get_parameter('allow_rotation_when_blocked').value)

        self.distance = math.inf
        self.last_sensor_time = 0.0

        self.cmd_pub = self.create_publisher(Twist, self.output_cmd_topic, 10)
        self.create_subscription(Twist, self.input_cmd_topic, self.cmd_callback, 10)
        self.create_subscription(Float32, self.ultrasonic_topic, self.distance_callback, 10)

        self.get_logger().info(
            f'ultrasonic_safety_node gating {self.input_cmd_topic} -> {self.output_cmd_topic} '
            f'(stop <= {self.stop_distance:.2f} m, slow <= {self.slow_distance:.2f} m)'
        )

    def distance_callback(self, msg: Float32):
        value = float(msg.data)
        if math.isfinite(value) and value >= 0.0:
            self.distance = value
            self.last_sensor_time = time.monotonic()

    def cmd_callback(self, msg: Twist):
        out = Twist()
        out.linear.x = float(msg.linear.x)
        out.angular.z = float(msg.angular.z)

        sensor_stale = (time.monotonic() - self.last_sensor_time) > self.stale_timeout

        if sensor_stale:
            # Fail-safe: if we've never heard from the ultrasonic sensor (or
            # it's gone quiet), don't trust a forward move.
            if out.linear.x > 0.0:
                out.linear.x = 0.0
                if not self.allow_rotation:
                    out.angular.z = 0.0
        elif self.distance <= self.stop_distance and out.linear.x > 0.0:
            out.linear.x = 0.0
            if not self.allow_rotation:
                out.angular.z = 0.0
        elif self.distance <= self.slow_distance and out.linear.x > 0.0:
            out.linear.x *= self.slow_factor

        self.cmd_pub.publish(out)


def main(args=None):
    rclpy.init(args=args)
    node = UltrasonicSafetyNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.cmd_pub.publish(Twist())
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
