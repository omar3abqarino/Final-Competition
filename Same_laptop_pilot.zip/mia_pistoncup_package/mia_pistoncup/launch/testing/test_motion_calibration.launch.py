"""test_motion_calibration.launch.py  (TESTING - not the competition launch)

Brings up ultrasonic_safety_node + motion_test together, so you can run
calibrated timed forward/rotate moves and measure the real result. See
tools/motion_test.py for parameter details (mode, magnitude, speeds).

This launch file intentionally does NOT set auto_start:=true -- override
it (and mode/magnitude/speed) on the command line for each measurement,
e.g.:

    ros2 launch mia_pistoncup test_motion_calibration.launch.py \\
        mode:=rotate_left magnitude:=30.0 angular_speed_radps:=0.5 auto_start:=true

Usage:
    ros2 launch mia_pistoncup test_motion_calibration.launch.py
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_share = get_package_share_directory('mia_pistoncup')
    default_params_file = os.path.join(pkg_share, 'config', 'params.yaml')

    params_file_arg = DeclareLaunchArgument(
        'params_file',
        default_value=default_params_file,
        description='Path to the YAML file with node parameters.',
    )
    mode_arg = DeclareLaunchArgument('mode', default_value='forward')
    magnitude_arg = DeclareLaunchArgument('magnitude', default_value='0.20')
    linear_speed_arg = DeclareLaunchArgument('linear_speed_mps', default_value='0.15')
    angular_speed_arg = DeclareLaunchArgument('angular_speed_radps', default_value='0.5')
    auto_start_arg = DeclareLaunchArgument('auto_start', default_value='false')

    params_file = LaunchConfiguration('params_file')

    ultrasonic_safety = Node(
        package='mia_pistoncup',
        executable='ultrasonic_safety_node',
        name='ultrasonic_safety_node',
        output='screen',
        parameters=[params_file],
    )
    motion_test = Node(
        package='mia_pistoncup',
        executable='motion_test',
        name='motion_test',
        output='screen',
        parameters=[params_file, {
            'mode': LaunchConfiguration('mode'),
            'magnitude': LaunchConfiguration('magnitude'),
            'linear_speed_mps': LaunchConfiguration('linear_speed_mps'),
            'angular_speed_radps': LaunchConfiguration('angular_speed_radps'),
            'auto_start': LaunchConfiguration('auto_start'),
        }],
    )

    return LaunchDescription([
        params_file_arg,
        mode_arg,
        magnitude_arg,
        linear_speed_arg,
        angular_speed_arg,
        auto_start_arg,
        ultrasonic_safety,
        motion_test,
    ])
