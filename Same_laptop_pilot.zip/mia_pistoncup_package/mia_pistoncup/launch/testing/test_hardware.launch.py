"""test_hardware.launch.py  (TESTING - not the competition launch)

Step 1 of hardware bring-up: confirms the ultrasonic sensor is wired up
and ultrasonic_safety_node is gating correctly, without commanding any
motion at all.

Usage:
    ros2 launch mia_pistoncup test_hardware.launch.py
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_share = get_package_share_directory('mia_pistoncup')
    default_params_file = os.path.join(pkg_share, 'config', 'params.yaml')

    params_file_arg = DeclareLaunchArgument(
        'params_file',
        default_value=default_params_file,
        description='Path to the YAML file with node parameters.',
    )
    params_file = LaunchConfiguration('params_file')

    ultrasonic_safety = Node(
        package='mia_pistoncup',
        executable='ultrasonic_safety_node',
        name='ultrasonic_safety_node',
        output='screen',
        parameters=[params_file],
    )
    ultrasonic_monitor = Node(
        package='mia_pistoncup',
        executable='ultrasonic_monitor',
        name='ultrasonic_monitor',
        output='screen',
        parameters=[params_file],
    )

    return LaunchDescription([
        params_file_arg,
        ultrasonic_safety,
        ultrasonic_monitor,
    ])
