import os
from glob import glob

from setuptools import find_packages, setup

package_name = 'mia_pistoncup'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
        # Testing/calibration launch files install into the SAME share/launch
        # directory (so `ros2 launch mia_pistoncup <file>.py` always works the
        # same way) even though they live in a separate launch/testing/ folder
        # in the source tree to keep them visually separated from the
        # competition launch file.
        (os.path.join('share', package_name, 'launch'), glob('launch/testing/*.py')),
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Your Team',
    maintainer_email='team@example.com',
    description='MIA Piston Cup competition ROS2 package: scroll detection + local teleop.',
    license='MIT',
    entry_points={
        'console_scripts': [
            # --- Competition-critical nodes ---
            'ultrasonic_safety_node = mia_pistoncup.ultrasonic_safety_node:main',
            'detection_node = mia_pistoncup.detection_node:main',
            'search_controller_node = mia_pistoncup.search_controller_node:main',
            'state_machine_node = mia_pistoncup.state_machine_node:main',
            'pilot_teleop_node = mia_pistoncup.pilot_teleop_node:main',
            # --- Testing/calibration tools (never used during a round) ---
            'motion_test = mia_pistoncup.tools.motion_test:main',
            'ultrasonic_monitor = mia_pistoncup.tools.ultrasonic_monitor:main',
        ],
    },
)
